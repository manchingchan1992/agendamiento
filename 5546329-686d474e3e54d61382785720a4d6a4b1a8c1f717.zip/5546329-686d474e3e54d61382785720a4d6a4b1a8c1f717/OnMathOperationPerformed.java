
public interface OnMathOperationPerformed {
  void onNumbersAdded();
}
