package dto;

public class Llamada {

	private int origen;
	private int duracionSegundos;
	
	

	public Llamada(int origen, int duracionSegundos, String estado) {
		this.origen = origen;
		this.duracionSegundos = duracionSegundos;
		
	}


	public int getOrigen() {
		return origen;
	}


	public void setOrigen(int origen) {
		this.origen = origen;
	}


	public int getDuracionSegundos() {
		return duracionSegundos;
	}

	public void setDuracionSegundos(int duracionSegundos) {
		this.duracionSegundos = duracionSegundos;
	}
	
	
}
