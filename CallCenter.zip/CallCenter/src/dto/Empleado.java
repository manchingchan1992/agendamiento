package dto;

public interface Empleado {
	public void atenderLlamada();
}
