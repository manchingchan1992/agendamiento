package dto;

public class Supervisor implements Empleado{

	private boolean ocupado;
	
	@Override
	public void atenderLlamada() {
		// TODO Auto-generated method stub
		
	}

	public boolean isOcupado() {
		return ocupado;
	}

	public void setOcupado(boolean ocupado) {
		this.ocupado = ocupado;
	}
}
