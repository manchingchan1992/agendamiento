package dto;

public class Operador implements Empleado{

	private boolean ocupado;
	
	@Override
	public void atenderLlamada() {
		
	}

	public boolean isOcupado() {
		return ocupado;
	}

	public void setOcupado(boolean ocupado) {
		this.ocupado = ocupado;
	}

}
