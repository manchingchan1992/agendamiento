package main;

import dto.Director;
import dto.Operador;
import dto.Supervisor;
import negocio.Dispatcher;

public class Principal {

	public static void main(String[] args) {
		
		Dispatcher dispatcher = new Dispatcher();
		dispatcher.getOperadores().add(new Operador());
		dispatcher.getOperadores().add(new Operador());
		dispatcher.getOperadores().add(new Operador());
		dispatcher.getSupervisores().add(new Supervisor());
		dispatcher.getSupervisores().add(new Supervisor());
		dispatcher.getDirectores().add(new Director());
		dispatcher.getDirectores().add(new Director());

	}

}
