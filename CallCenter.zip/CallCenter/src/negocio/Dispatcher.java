package negocio;

import java.util.ArrayList;
import java.util.List;

import dto.Llamada;
import dto.Operador;
import dto.Director;
import dto.Empleado;
import dto.Supervisor;

public class Dispatcher {

	private List<Empleado> operadores ;
	private List<Empleado> supervisores;
	private List<Empleado> directores;
	
	public Dispatcher(){
		operadores = new ArrayList<>();
		supervisores = new ArrayList<>();
		directores = new ArrayList<>();
	}
	
	public void dispatcCall(Llamada llamada){
		if(validarDisponibilidad(operadores)){
			
		}else if(validarDisponibilidad(supervisores)){
			
			
		}else if(validarDisponibilidad(directores)){
			
		}
	}
	
	public boolean validarDisponibilidad(List<Empleado> empleados){
		for(Empleado e:empleados){
			if(e instanceof Operador){
				if(((Operador)e).isOcupado()){
					
				}
			}else if(e instanceof Supervisor){
				if(((Supervisor)e).isOcupado()){
					
				}
			}else{
				if(((Director)e).isOcupado()){
					
				}
			}
		}
		return false;
	}

	public List<Empleado> getOperadores() {
		return operadores;
	}

	public void setOperadores(List<Empleado> operadores) {
		this.operadores = operadores;
	}

	public List<Empleado> getSupervisores() {
		return supervisores;
	}

	public void setSupervisores(List<Empleado> supervisores) {
		this.supervisores = supervisores;
	}

	public List<Empleado> getDirectores() {
		return directores;
	}

	public void setDirectores(List<Empleado> directores) {
		this.directores = directores;
	}

}
