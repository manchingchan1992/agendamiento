import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { CallNumber } from '@ionic-native/call-number';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { ConsultarPinPage } from '../pages/consultar-pin/consultar-pin';
import { GenerarCertificadoPage } from '../pages/generar-certificado/generar-certificado';
import { OpcionesUsuarioPage } from '../pages/opciones-usuario/opciones-usuario';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    LoginPage,
    ConsultarPinPage,
    GenerarCertificadoPage,
    OpcionesUsuarioPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    LoginPage,
    ConsultarPinPage,
    GenerarCertificadoPage,
    OpcionesUsuarioPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    CallNumber,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
