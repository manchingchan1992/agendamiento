import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { CallNumber } from '@ionic-native/call-number';
import { StatusBar } from '@ionic-native/status-bar';
import { HttpClientModule } from '@angular/common/http';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { DocumentViewer } from '@ionic-native/document-viewer';

import { NativeHttpFallback, NativeHttpModule } from 'ionic-native-http-connection-backend';
import { RequestOptions, Http } from '@angular/http';



import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { ConsultarPinPage } from '../pages/consultar-pin/consultar-pin';
import { GenerarCertificadoPage } from '../pages/generar-certificado/generar-certificado';
import { OpcionesUsuarioPage } from '../pages/opciones-usuario/opciones-usuario';
import { ResultadoConsultaPinPage } from '../pages/resultado-consulta-pin/resultado-consulta-pin';
import { ResultadoGeneracionCertificadoPage } from '../pages/resultado-generacion-certificado/resultado-generacion-certificado';
import { ConsultarPinServiceProvider } from '../providers/consultar-pin-service/consultar-pin-service';
import { GenerarCertificadoServiceProvider } from '../providers/generar-certificado-service/generar-certificado-service';



@NgModule({
  declarations: [
    MyApp,
    HomePage,
    LoginPage,
    ConsultarPinPage,
    GenerarCertificadoPage,
    OpcionesUsuarioPage,
    ResultadoConsultaPinPage,
    ResultadoGeneracionCertificadoPage
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    NativeHttpModule, 
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    LoginPage,
    ConsultarPinPage,
    GenerarCertificadoPage,
    OpcionesUsuarioPage,
    ResultadoConsultaPinPage,
    ResultadoGeneracionCertificadoPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    CallNumber,
    InAppBrowser,
    DocumentViewer,
    {provide:[ErrorHandler, Http] , useClass: IonicErrorHandler,deps: [NativeHttpFallback, RequestOptions]},
    ConsultarPinServiceProvider,
    GenerarCertificadoServiceProvider
  ]
})
export class AppModule {}