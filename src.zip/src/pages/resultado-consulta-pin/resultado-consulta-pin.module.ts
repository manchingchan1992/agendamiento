import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResultadoConsultaPinPage } from './resultado-consulta-pin';

@NgModule({
  declarations: [
    ResultadoConsultaPinPage,
  ],
  imports: [
    IonicPageModule.forChild(ResultadoConsultaPinPage),
  ],
})
export class ResultadoConsultaPinPageModule {}
