import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ConsultarPinServiceProvider } from '../../providers/consultar-pin-service/consultar-pin-service';
import { CallNumber } from '@ionic-native/call-number';
import { LoadingController } from 'ionic-angular';
/**
 * Generated class for the ResultadoConsultaPinPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-resultado-consulta-pin',
  templateUrl: 'resultado-consulta-pin.html',
})
export class ResultadoConsultaPinPage {
  
  registros: any[] = [];

  public tipoDocumento: string;
  public numeroDocumento : string;
  public anio: string;
  public mes: string;
  public numeroPin : string;

  constructor(public navCtrl: NavController, public navParams: NavParams,
    public consultarPinServiceProvider: ConsultarPinServiceProvider,public callNumber: CallNumber,
    public loadingCtrl: LoadingController) {
      this.tipoDocumento = navParams.get('tipoDocumento');
      this.numeroDocumento = navParams.get('numeroDocumento');
      this.anio = navParams.get('fechaPeriodo').split("-")[0];
      this.mes = navParams.get('fechaPeriodo').split("-")[1];
  }

  activarLlamada(){
    this.callNumber.callNumber("+5714854471", true).then(() => console.log('Launched dialer!'))
    .catch(() => console.log('Error launching dialer'))
  }

  ionViewDidLoad() {
    let loader = this.loadingCtrl.create({
      content: "Cargando..."
    });
    loader.present();
   this.consultarPinServiceProvider.getPin(this.tipoDocumento,this.numeroDocumento,this.mes,this.anio).subscribe(
      (data)=>{   
        this.registros = data['results'];
        loader.dismiss();
      },  
      (error) =>{
        console.log(error)
        loader.dismiss();
      }
    )
    
  }

}