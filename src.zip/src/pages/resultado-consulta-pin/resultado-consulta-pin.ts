import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ConsultarPinServiceProvider } from '../../providers/consultar-pin-service/consultar-pin-service';
import { CallNumber } from '@ionic-native/call-number';
import { LoadingController } from 'ionic-angular';
import { MecanismosPagoPage } from '../../pages/mecanismos-pago/mecanismos-pago';
/**
 * Generated class for the ResultadoConsultaPinPage page.
 *
 * Clase que se inicia cuando  se presentan resultados en la consulta pin y procesa los datos
 * que entran por parametro (registros, tipoDocumento, numeroDocumento )
 * @DiegoAlvarez
 */

@IonicPage()
@Component({
  selector: 'page-resultado-consulta-pin',
  templateUrl: 'resultado-consulta-pin.html',
})
export class ResultadoConsultaPinPage {

  registros: any[] = [];

  public tipoDocumento: string;
  public numeroDocumento: string;
  public anio: string;
  public mes: string;
  public numeroPin: string;

  //date: any = new Date();
  fechaActual: String; //

  constructor(public navCtrl: NavController, public navParams: NavParams,
    public consultarPinServiceProvider: ConsultarPinServiceProvider, public callNumber: CallNumber,
    public loadingCtrl: LoadingController) {
      this.fechaActual = this.transformarFechaActual(new Date());
    this.registros = navParams.get('registros');
    this.tipoDocumento = navParams.get('tipoDocumento');
    this.numeroDocumento = navParams.get('numeroDocumento');
    
  }

  activarLlamada() {
    this.callNumber.callNumber("+5714854471", true).then(() => console.log('Plugin llamar'))
      .catch(() => console.log('Error launching dialer'))
  }

  convertirMes(mes) {
    var mesLiteral;

    return mesLiteral;
  }

  direccionarMecanismosPago(modalidad: string) {
    this.navCtrl.push(MecanismosPagoPage, {
      modalidad: modalidad,
    })
  }

  //Función que permite formatear fecha actual a formato de respuesta webService campo  "fechaTrabajo"
  transformarFechaActual(date) {
    var yyyy = date.getFullYear().toString();
    var mm = (date.getMonth() + 1).toString();
    var dd = date.getDate().toString();
    var mmChars = mm.split('');
    var ddChars = dd.split('');
    var fecha = yyyy + '-' + (mmChars[1] ? mm : "0" + mmChars[0]) + '-' + (ddChars[1] ? dd : "0" + ddChars[0]);
    var res = fecha.split("-");
    var mesLiteral;
    switch (res[1]) {
      case "01":
        mesLiteral = "ene";
        break;
      case "02":
        mesLiteral = "feb";
        break;
      case "3":
        mesLiteral = "mar";
        break;
      case "4":
        mesLiteral = "abr";
        break;
      case "5":
        mesLiteral = "may";
        break;
      case "6":
        mesLiteral = "jun";
        break;
      case "7":
        mesLiteral = "jul";
      case "8":
        mesLiteral = "ago";
      case "9":
        mesLiteral = "sep";
      case "10":
        mesLiteral = "oct";
      case "11":
        mesLiteral = "nov";
      case "12":
        mesLiteral = "dic";
    }

    return mesLiteral + " " + res[2] + ", " + res[0];
  }

  ionViewDidLoad() {

  }

}