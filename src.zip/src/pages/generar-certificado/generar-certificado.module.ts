import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GenerarCertificadoPage } from './generar-certificado';

@NgModule({
  declarations: [
    GenerarCertificadoPage,
  ],
  imports: [
    IonicPageModule.forChild(GenerarCertificadoPage),
  ],
})
export class GenerarCertificadoPageModule {}
