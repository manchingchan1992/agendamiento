import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { ResultadoGeneracionCertificadoPage } from '../../pages/resultado-generacion-certificado/resultado-generacion-certificado';
/**
 * Generated class for the GenerarCertificadoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-generar-certificado',
  templateUrl: 'generar-certificado.html',
})
export class GenerarCertificadoPage {

  tipoDocumento: AbstractControl;
  numeroDocumento: AbstractControl;
  fechaPeriodo:AbstractControl;
  errorMessage: string = null;
  generarCertificadoForm: FormGroup;
  
  constructor(public navCtrl: NavController, public navParams: NavParams,
    private fb: FormBuilder) {

      this.generarCertificadoForm = fb.group({
        'tipoDocumento': ['', Validators.compose([Validators.required])],
        'numeroDocumento': ['', Validators.compose([Validators.required])],
        'fechaPeriodo': ['', Validators.compose([Validators.required])]
      });
    
    this.tipoDocumento = this.generarCertificadoForm.controls['tipoDocumento'];
    this.numeroDocumento = this.generarCertificadoForm.controls['numeroDocumento'];  
    this.fechaPeriodo = this.generarCertificadoForm.controls['fechaPeriodo'];
  }
 
  generarCertificado(){
    //this.navCtrl.push(ResultadoGeneracionCertificadoPage);
    this.navCtrl.push(ResultadoGeneracionCertificadoPage,{
      tipoDocumento : this.tipoDocumento.value,
      numeroDocumento : this.numeroDocumento.value,
      fechaPeriodo : this.fechaPeriodo.value                                                                                                                                                                                                                                                                                                                                                                                                                               
    })
  }

  ionViewDidLoad() {

  }

}
