import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { ResultadoGeneracionCertificadoPage } from '../../pages/resultado-generacion-certificado/resultado-generacion-certificado';
import { GenerarCertificadoServiceProvider } from '../../providers/generar-certificado-service/generar-certificado-service';
import { Platform } from 'ionic-angular';
import { File } from '@ionic-native/file';
import { FileOpener } from '@ionic-native/file-opener';
import { LoadingController } from 'ionic-angular';

/**
 * Generated class for the GenerarCertificadoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-generar-certificado',
  templateUrl: 'generar-certificado.html',
})
export class GenerarCertificadoPage {

  certificado: any[] = [];

  tipoDocumento: AbstractControl;
  numeroDocumento: AbstractControl;
  fechaPeriodo: AbstractControl;
  anio: string;
  mes: string;
  errorMessage: string = null;
  generarCertificadoForm: FormGroup;

  constructor(public navCtrl: NavController, public navParams: NavParams,
    private fb: FormBuilder, public generarCertificadoServiceProvide: GenerarCertificadoServiceProvider,
    public platform: Platform, private file: File, private fileOpener: FileOpener,
    public loadingCtrl: LoadingController) {

    this.generarCertificadoForm = fb.group({
      'tipoDocumento': ['', Validators.compose([Validators.required])],
      'numeroDocumento': ['', Validators.compose([Validators.required])],
      'fechaPeriodo': ['', Validators.compose([Validators.required])]
    });

    this.tipoDocumento = this.generarCertificadoForm.controls['tipoDocumento'];
    this.numeroDocumento = this.generarCertificadoForm.controls['numeroDocumento'];
    this.fechaPeriodo = this.generarCertificadoForm.controls['fechaPeriodo'];

  }

  generarCertificado() {
    let loader = this.loadingCtrl.create({
      content: "Cargando"
    });
    loader.present();

    if(this.tipoDocumento.value === '' || this.numeroDocumento.value === '' || this.fechaPeriodo.value === ''){
      alert("Por favor diligenciar todos los campos ");
      loader.dismiss(); 
    }else{
      this.anio = this.fechaPeriodo.value.split("-")[0];
      this.mes = this.fechaPeriodo.value.split("-")[1];
  
      this.generarCertificadoServiceProvide.getCertificado(this.tipoDocumento.value, this.numeroDocumento.value, this.mes, this.anio).subscribe(
        (data) => {
          this.certificado = data['results'];
          if (this.certificado.length > 0) {
            for (let cert of this.certificado) {
              console.log(cert.documento);
              this.getPDF(cert.documento);
              break;
            }
          }else{
            this.navCtrl.push(ResultadoGeneracionCertificadoPage,{
              conexion: true
              
            });
          }
          //loader.dismiss();
        },
        (error) => {
          this.navCtrl.push(ResultadoGeneracionCertificadoPage,{
            conexion: false
          });
          //
        }
      )
      loader.dismiss();
    }
    
  }

  public getPDF(dataBlob) {

    let blob: Blob = this.b64toBlob(dataBlob, 'application/pdf');
    let pathFile: string;

    if (this.platform.is("ios")) {
      console.log('ios detectado');
      pathFile = this.file.documentsDirectory; //cordova.file.dataDirectory;  externalDataDirectory
    } else {
      console.log('other platform');
      pathFile = this.file.externalDataDirectory; //cordova.file.dataDirectory;  externalDataDirectory
    }

    console.log(pathFile);

    let fileName: string = this.numeroDocumento+"_certificado.pdf";

    console.log("Iniciando escritura de archivo pdf");

    this.file.writeFile(pathFile, fileName, blob, { replace: true }).then((entry) => {

      console.log(pathFile);

      this.fileOpener.open(pathFile + fileName, 'application/pdf')
        .then(() => console.log('File is opened'))
        .catch(e => console.log('Error openening file', e));

    }).catch((error) => {
      console.log('Error abriendo PDF:');
      console.log(error);
    });

  }


  public b64toBlob(b64Data, contentType): Blob {
    contentType = contentType || '';
    let sliceSize = 512;

    var byteCharacters = atob(b64Data);
    var byteArrays = [];

    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      var slice = byteCharacters.slice(offset, offset + sliceSize);

      var byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }

      var byteArray = new Uint8Array(byteNumbers);

      byteArrays.push(byteArray);
    }

    var blob = new Blob(byteArrays, { type: contentType });
    return blob;

  }

  ionViewDidLoad() {

  }

}
