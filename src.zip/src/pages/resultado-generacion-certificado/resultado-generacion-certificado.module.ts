import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResultadoGeneracionCertificadoPage } from './resultado-generacion-certificado';

@NgModule({
  declarations: [
    ResultadoGeneracionCertificadoPage,
  ],
  imports: [
    IonicPageModule.forChild(ResultadoGeneracionCertificadoPage),
  ],
})
export class ResultadoGeneracionCertificadoPageModule {}
