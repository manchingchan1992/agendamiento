import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { GenerarCertificadoServiceProvider } from '../../providers/generar-certificado-service/generar-certificado-service';
import { CallNumber } from '@ionic-native/call-number';
import { DocumentViewer,DocumentViewerOptions } from '@ionic-native/document-viewer';
import { InAppBrowser,InAppBrowserOptions } from '@ionic-native/in-app-browser';

/**
 * Generated class for the ResultadoGeneracionCertificadoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-resultado-generacion-certificado',
  templateUrl: 'resultado-generacion-certificado.html',
})
export class ResultadoGeneracionCertificadoPage {

  certificado: any[] = [];

  public tipoDocumento: string;
  public numeroDocumento : string;
  public anio: string;
  public mes: string;
  
  options : InAppBrowserOptions = {
    location : 'yes',//Or 'no' 
    hidden : 'no', //Or  'yes'
    clearcache : 'yes',
    clearsessioncache : 'yes',
    zoom : 'yes',//Android only ,shows browser zoom controls 
    hardwareback : 'yes',
    mediaPlaybackRequiresUserAction : 'no',
    shouldPauseOnSuspend : 'no', //Android only 
    closebuttoncaption : 'Close', //iOS only
    disallowoverscroll : 'no', //iOS only 
    toolbar : 'yes', //iOS only 
    enableViewportScale : 'no', //iOS only 
    allowInlineMediaPlayback : 'no',//iOS only 
    presentationstyle : 'pagesheet',//iOS only 
    fullscreen : 'yes',//Windows only    
};

opt: DocumentViewerOptions = {
  title: 'My PDF'
};

  constructor(public navCtrl: NavController, public navParams: NavParams,
    public generarCertificadoServiceProvide : GenerarCertificadoServiceProvider,
    public callNumber : CallNumber,public iab: InAppBrowser,private document: DocumentViewer) {
      this.tipoDocumento = navParams.get('tipoDocumento');
      this.numeroDocumento = navParams.get('numeroDocumento');
      this.anio = navParams.get('fechaPeriodo').split("-")[0];
      this.mes = navParams.get('fechaPeriodo').split("-")[1];
      
      //alert(this.numeroDocumento);
  }


  public open(){
    this.document.viewDocument('../assets/imgs/pdf.pdf', 'application/pdf',this.opt);
  }

  public openWithSystemBrowser(url : string){
    let target = "_system";
    this.iab.create(url,target,this.options);
  };
  public  openWithInAppBrowser(url : string){
    let target = "_blank";
    this.iab.create(url,target,this.options);
  };
  public openWithCordovaBrowser(url : string){
    let target = "_self";
    this.iab.create(url,target,this.options);
  };

  /*activarLlamada(){
    this.callNumber.callNumber("+5714854471", true).then(() => console.log('Launched dialer!'))
    .catch(() => console.log('Error launching dialer'))
  }*/

  ionViewDidLoad() {
    this.generarCertificadoServiceProvide.getCertificado(this.tipoDocumento,this.numeroDocumento,this.mes,this.anio).subscribe(
      (data)=>{   
        this.certificado = data['results'];
        for (let cert of this.certificado) {
          console.log(cert.documento);
          console.log(atob(cert.documento)); // password
      }
      },
      (error) =>{
        console.log(error)
      }
    )
  }

}


