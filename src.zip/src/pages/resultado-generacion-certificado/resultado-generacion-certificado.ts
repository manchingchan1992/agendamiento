import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { GenerarCertificadoServiceProvider } from '../../providers/generar-certificado-service/generar-certificado-service';
import { CallNumber } from '@ionic-native/call-number';
//import { DocumentViewer,DocumentViewerOptions } from '@ionic-native/document-viewer';
//import { InAppBrowser,InAppBrowserOptions } from '@ionic-native/in-app-browser';
import { Platform } from 'ionic-angular';
import { File } from '@ionic-native/file';
import { FileOpener } from '@ionic-native/file-opener';


/**
 * Generated class for the ResultadoGeneracionCertificadoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-resultado-generacion-certificado',
  templateUrl: 'resultado-generacion-certificado.html',
})
export class ResultadoGeneracionCertificadoPage {

  certificado: any[] = [];

  public tipoDocumento: string;
  public numeroDocumento : string;
  public anio: string;
  public mes: string;


constructor(public navCtrl: NavController, public navParams: NavParams,
    public generarCertificadoServiceProvide : GenerarCertificadoServiceProvider,
    public callNumber : CallNumber,
    public platform: Platform, private file: File,private fileOpener: FileOpener) {
      /*this.tipoDocumento = navParams.get('tipoDocumento');
      this.numeroDocumento = navParams.get('numeroDocumento');
      this.anio = navParams.get('fechaPeriodo').split("-")[0];
      this.mes = navParams.get('fechaPeriodo').split("-")[1];*/
  }

  activarLlamada(){
    this.callNumber.callNumber("+5714854471", true).then(() => console.log('Launched dialer!'))
    .catch(() => console.log('Error launching dialer'))
  }



  /*public getPDF(dataBlob) {
    
    let blob: Blob = this.b64toBlob(dataBlob, 'application/pdf');
    let pathFile: string;
    
    if (this.platform.is("ios")) {
      console.log('ios detectado');
      pathFile = this.file.documentsDirectory; //cordova.file.dataDirectory;  externalDataDirectory
    } else {
      console.log('other platform');
      pathFile = this.file.externalDataDirectory; //cordova.file.dataDirectory;  externalDataDirectory
    }
    
    console.log(pathFile);
    
    let fileName : string = "snMaterialEscolar.pdf";
    
    console.log("Iniciando escritura de archivo pdf");
    
    this.file.writeFile(pathFile,fileName, blob, {replace:true} ).then((entry)=>{
    
      console.log(pathFile);
    
      this.fileOpener.open(pathFile + fileName, 'application/pdf')
      .then(() => console.log('File is opened'))
      .catch(e => console.log('Error openening file', e));
    
    }).catch((error)=>{
      console.log('Error abriendo PDF:');
      console.log(error);
    });
    
    }*/

    /*private onShow(){
      window.console.log('Exibir documento.');
      //e.g. track document usage
      }
      
      private onClose(){
      window.console.log('Fechar documento');
      //e.g. remove temp files
      }
      
      private onMissingApp(appId, installer) {
      if (confirm("desea instalar aplicacion para visualización de archivos pdf " + appId )) { installer(); }
      }
      
      private onError(error) {
      window.console.log(error);
      alert("Error al abrir pdf.");
      }*/

 /* public b64toBlob(b64Data, contentType) : Blob {
    contentType = contentType || '';
    let sliceSize = 512;
    
        var byteCharacters = atob(b64Data);
        var byteArrays = [];
    
        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);
    
            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }
    
            var byteArray = new Uint8Array(byteNumbers);
    
            byteArrays.push(byteArray);
        }
    
      var blob = new Blob(byteArrays, {type: contentType});
      return blob;
    
    }*/

  ionViewDidLoad() {
    /*this.generarCertificadoServiceProvide.getCertificado(this.tipoDocumento,this.numeroDocumento,this.mes,this.anio).subscribe(
      (data)=>{   
        this.certificado = data['results'];
        for (let cert of this.certificado) {
          console.log(cert.documento);
          //console.log(atob(cert.documento)); // password
          this.getPDF(cert.documento);
          break;
      }
      },
      (error) =>{
        console.log(error)
      }
    )*/
  }

}


