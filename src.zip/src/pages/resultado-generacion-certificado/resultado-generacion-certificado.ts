import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { GenerarCertificadoServiceProvider } from '../../providers/generar-certificado-service/generar-certificado-service';
import { CallNumber } from '@ionic-native/call-number';
import { Platform } from 'ionic-angular';
import { File } from '@ionic-native/file';
import { FileOpener } from '@ionic-native/file-opener';


/**
 * Generated class for the ResultadoGeneracionCertificadoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-resultado-generacion-certificado',
  templateUrl: 'resultado-generacion-certificado.html',
})
export class ResultadoGeneracionCertificadoPage {

  public conexion: boolean;
  

constructor(public navCtrl: NavController, public navParams: NavParams,
    public generarCertificadoServiceProvide : GenerarCertificadoServiceProvider,
    public callNumber : CallNumber,
    public platform: Platform, private file: File,private fileOpener: FileOpener) {
    this.conexion = navParams.get('conexion');
  }

  activarLlamada(){
    this.callNumber.callNumber("+5714854471", true).then(() => console.log('Launched dialer!'))
    .catch(() => console.log('Error launching dialer'))
  }

  ionViewDidLoad() {
   
  }

}


