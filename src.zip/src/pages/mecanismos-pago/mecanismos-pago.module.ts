import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MecanismosPagoPage } from './mecanismos-pago';

@NgModule({
  declarations: [
    MecanismosPagoPage,
  ],
  imports: [
    IonicPageModule.forChild(MecanismosPagoPage),
  ],
})
export class MecanismosPagoPageModule {}
