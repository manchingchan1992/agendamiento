import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the ResultadoConsultaPinPage page.
 *
 * Clase que recibe la modalidad de planilla (electronica - asistida - agrario) con el objetivo de 
 *  permitir mostrar los diferente mecanismo de pago según corresponda 
 * @DiegoAlvarez
 */

@IonicPage()
@Component({
  selector: 'page-mecanismos-pago',
  templateUrl: 'mecanismos-pago.html',
})
export class MecanismosPagoPage {

  public modalidad: string;

  constructor(public navCtrl: NavController, public navParams: NavParams,) {
    this.modalidad = navParams.get('modalidad');
  }

  ionViewDidLoad() {
    
  }

}
