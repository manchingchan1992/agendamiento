import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import FORM_DIRECTIVES from '@angular/forms';
import REACTIVE_FORM_DIRECTIVES from '@angular/forms';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { HomePage } from '../../pages/home/home';
import { ConsultarPinPage } from '../../pages/consultar-pin/consultar-pin';
import { GenerarCertificadoPage } from '../../pages/generar-certificado/generar-certificado';
import { OpcionesUsuarioPage } from '../../pages/opciones-usuario/opciones-usuario';
import { CallNumber } from '@ionic-native/call-number';



@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  username: AbstractControl;
  password: AbstractControl;
  errorMessage: string = null;
  loginForm: FormGroup;
  

  constructor(public navCtrl: NavController, public navParams: NavParams, private fb: FormBuilder,public callNumber: CallNumber) {
    this.loginForm = fb.group({
      'username': ['', Validators.compose([Validators.required])],
      'password': ['', Validators.compose([Validators.required])]
    });

    this.username = this.loginForm.controls['username'];
    this.password = this.loginForm.controls['password'];
  }
  login() {
    alert("Esta opción estara habilitada proximamente, por el momento puedes consultar tu referencia y certificado de pago");
    //this.navCtrl.push(OpcionesUsuarioPage);
  }
  direccionarPagConsultarPin() {
    this.navCtrl.push(ConsultarPinPage);
  }

  direccionarPagGenerarCertificado() {
    this.navCtrl.push(GenerarCertificadoPage);
  }

  activarLlamada(){
    this.callNumber.callNumber("+5714854471", true).then(() => console.log('Launched dialer!'))
    .catch(() => console.log('Error launching dialer'))
  }
  ionViewDidLoad() {

  }

}
