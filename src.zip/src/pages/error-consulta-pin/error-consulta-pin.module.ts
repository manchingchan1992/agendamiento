import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ErrorConsultaPinPage } from './error-consulta-pin';

@NgModule({
  declarations: [
    ErrorConsultaPinPage,
  ],
  imports: [
    IonicPageModule.forChild(ErrorConsultaPinPage),
  ],
})
export class ErrorConsultaPinPageModule {}
