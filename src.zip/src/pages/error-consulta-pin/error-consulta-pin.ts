import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { CallNumber } from '@ionic-native/call-number';

/**
 * Generated class for the ErrorConsultaPinPage page.
 *
 * Clase que se inicia cuando se consulta referencia (pin)  de pago y no se encuentran resultrados o el
 * dispositivo no tiene una conexión a internet
 * @DiegoAlvarez 
 */

@IonicPage()
@Component({
  selector: 'page-error-consulta-pin',
  templateUrl: 'error-consulta-pin.html',
})
export class ErrorConsultaPinPage {

  public conexion: boolean;

  constructor(public navCtrl: NavController, public navParams: NavParams,public callNumber : CallNumber,) {
    this.conexion = navParams.get('conexion');
  }


  activarLlamada(){
    this.callNumber.callNumber("+5714854471", true).then(() => console.log('Launched dialer!'))
    .catch(() => console.log('Error launching dialer'))
  }


  ionViewDidLoad() {
    
  }

}
