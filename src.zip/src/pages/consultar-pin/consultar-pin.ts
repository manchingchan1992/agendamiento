import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { ResultadoConsultaPinPage } from '../../pages/resultado-consulta-pin/resultado-consulta-pin';
/**
 * Generated class for the ConsultarPinPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-consultar-pin',
  templateUrl: 'consultar-pin.html',
})
export class ConsultarPinPage {

  tipoDocumento: AbstractControl;
  numeroDocumento: AbstractControl;
  fechaPeriodo: AbstractControl;
  errorMessage: string = null;
  consultaPinForm: FormGroup;

  constructor(public navCtrl: NavController, public navParams: NavParams,
    private fb: FormBuilder) {

    this.consultaPinForm = fb.group({
      'tipoDocumento': ['', Validators.compose([Validators.required])],
      'numeroDocumento': ['', Validators.compose([Validators.required])],
      'fechaPeriodo': ['', Validators.compose([Validators.required])]
    });

    this.tipoDocumento = this.consultaPinForm.controls['tipoDocumento'];
    this.numeroDocumento = this.consultaPinForm.controls['numeroDocumento'];
    this.fechaPeriodo = this.consultaPinForm.controls['fechaPeriodo'];
  }

  consultarPin() {
    if (this.tipoDocumento.value === '' || this.numeroDocumento.value === '' || this.fechaPeriodo.value === '') {
      alert("Por favor diligenciar todos los campos ");
    } else {
      this.navCtrl.push(ResultadoConsultaPinPage, {
        tipoDocumento: this.tipoDocumento.value,
        numeroDocumento: this.numeroDocumento.value,
        fechaPeriodo: this.fechaPeriodo.value
      })
    }

  }

  ionViewDidLoad() {
    /*this.consultarPinServiceProvider.getUsers().subscribe(
       (data)=>{
         this.users = data['results'];
       },
       (error) =>{
         console.log(error)
       }
     )
     console.log('ionViewDidLoad ConsultarPinPage');*/
  }

}
