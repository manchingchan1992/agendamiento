import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { ResultadoConsultaPinPage } from '../../pages/resultado-consulta-pin/resultado-consulta-pin';
import { ConsultarPinServiceProvider } from '../../providers/consultar-pin-service/consultar-pin-service';
import { ErrorConsultaPinPage } from '../../pages/error-consulta-pin/error-consulta-pin';
import { LoadingController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
/**
 * Generated class for the ConsultarPinPage page.
 *
 * Clase que recibe los datos para realizar consulta de pin y realizar llamado al
 * provider 'consultarPinServiceProvider' que retorna el resultado de petición al 
 * Rest
 * @DiegoAlvarez
 */
@IonicPage()
@Component({
  selector: 'page-consultar-pin',
  templateUrl: 'consultar-pin.html',
})
export class ConsultarPinPage {

  registros: any[] = [];

  tipoDocumento: AbstractControl;
  numeroDocumento: AbstractControl;
  fechaPeriodo: AbstractControl;
  errorMessage: string = null;
  consultaPinForm: FormGroup;
  public anio: string;
  public mes: string;

  date : any = new Date().toISOString();
  currentYear : any = (new Date()).getFullYear();

  constructor(public navCtrl: NavController, public navParams: NavParams,
    private fb: FormBuilder,public consultarPinServiceProvider: ConsultarPinServiceProvider,
    public loadingCtrl: LoadingController,public alertCtrl: AlertController) {

    this.consultaPinForm = fb.group({
      'tipoDocumento': ['', Validators.compose([Validators.required])],
      'numeroDocumento': ['', Validators.compose([Validators.required])],
      'fechaPeriodo': ['', Validators.compose([Validators.required])]
    });

    this.tipoDocumento = this.consultaPinForm.controls['tipoDocumento'];
    this.numeroDocumento = this.consultaPinForm.controls['numeroDocumento'];
    this.fechaPeriodo = this.consultaPinForm.controls['fechaPeriodo'];
  }

  consultarPin() {
    if (this.tipoDocumento.value === '' || this.numeroDocumento.value === '' || this.fechaPeriodo.value === '') {
      let alert = this.alertCtrl.create({
        title: 'Información',
        subTitle: "Por favor diligenciar todos los campos ",
        buttons: ["Aceptar"]
      });
      alert.present();
    } else {

      this.anio = this.fechaPeriodo.value.split("-")[0];
      this.mes = this.fechaPeriodo.value.split("-")[1];

      let loader = this.loadingCtrl.create({
        content: "Cargando"
      });
      loader.present();
        this.consultarPinServiceProvider.getPin(this.tipoDocumento.value,this.numeroDocumento.value,this.mes,this.anio).subscribe(
        (data)=>{
          this.registros = data['results'];
          if(this.registros.length > 0){
            this.navCtrl.push(ResultadoConsultaPinPage, {
              registros: this.registros,
              tipoDocumento: this.tipoDocumento.value,
              numeroDocumento: this.numeroDocumento.value,
            })
          }else{
            this.navCtrl.push(ErrorConsultaPinPage,{
              conexion: true
            });
          }
          loader.dismiss();
        },  
        (error) =>{
          console.log(error)
          this.navCtrl.push(ErrorConsultaPinPage,{
            conexion: false
          });
          loader.dismiss();
        }
      )
    }

  }
  ionViewDidLoad() {
    
  }

}
