import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConsultarPinPage } from './consultar-pin';

@NgModule({
  declarations: [
    ConsultarPinPage,
  ],
  imports: [
    IonicPageModule.forChild(ConsultarPinPage),
  ],
})
export class ConsultarPinPageModule {}



