import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OpcionesUsuarioPage } from './opciones-usuario';

@NgModule({
  declarations: [
    OpcionesUsuarioPage,
  ],
  imports: [
    IonicPageModule.forChild(OpcionesUsuarioPage),
  ],
})
export class OpcionesUsuarioPageModule {}
