import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { HomePage } from '../../pages/home/home';


@IonicPage()
@Component({
  selector: 'page-opciones-usuario',
  templateUrl: 'opciones-usuario.html',
})
export class OpcionesUsuarioPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  prueba(){
    this.navCtrl.push(HomePage);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad OpcionesUsuarioPage');
  }

}
