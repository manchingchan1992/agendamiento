import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

/*
  Generated class for the ConexionTestServiceProvider provider.
  @DiegoAlvarez
*/
@Injectable()
export class ConexionTestServiceProvider {

  constructor(public http: Http) {
    console.log('Hello ConexionTestServiceProvider Provider');
  }

  getTest(){
    return this.http.get('https://www.enlace-apb.com/interssi/rest/app/testRespuesta/'); 
    //return this.http.get('https://10.1.0.151/interssi/rest/app/testRespuesta/'); 

  }

}
