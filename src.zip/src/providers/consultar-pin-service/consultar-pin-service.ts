import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { NativeHttpFallback, NativeHttpModule } from 'ionic-native-http-connection-backend';
import { RequestOptions, Http } from '@angular/http';
import 'rxjs/add/operator/map';

/*
  Generated class for the ConsultarPinServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ConsultarPinServiceProvider {

  constructor(private http: HttpClient) {
    console.log('Esto es modelo servicio');
  }

  getPin(tipoDocumento : string , numeroDocumento:string , mesPeriodo:string, anioPeriodo:string){    
    return this.http.get('https://www.enlace-apb.com/interssi/rest/app/consultarPin/'+tipoDocumento+'/'+numeroDocumento+'/'+anioPeriodo+'/'+mesPeriodo); 
    //return this.http.get('https://10.1.0.151/interssi/rest/app/consultarPin/'+tipoDocumento+'/'+numeroDocumento+'/'+anioPeriodo+'/'+mesPeriodo);  
  }
}