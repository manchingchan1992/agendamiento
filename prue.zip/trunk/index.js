'use strict';

const HAPI = require('hapi');
const INERT = require('inert');
const VISION = require('vision');
const Bcrypt = require("bcrypt");
const PATH = require('path');
const AUTH_COOKIE = require('hapi-auth-cookie');
const PASS_COOKIE = 'TTNlZBKxaxD/XBL5OU1flrzWHkaO/0uXfrhurtSbex4ZFR6dV5pMfYTva7pI18ZHxNO7K/e63bgpJtARbZha/CuunGV21mtB7tT18RxlNry350eHBHyOCzrHguL9IjxlDvsBbI0Kbo9KYV5JRcnZcI1kVR5MBL0AQ0y/adx1ZxosuWee+5+cfTYSRWaywwEO4LuABMNJ07lmyj2/JLuT77zs32uAigOYRHfal83JXxK0nBMdCSQjWlKoQelWrH9ih/2aK2ox4w0B/D9V5MKA8VV/NVL1o+9ZtxZKY/F9GRU+a/uooytdf+97AKngFvxgKkxIOC7vCrX5J+oW7zP+Zw==';
const JWT = require('jsonwebtoken');
const BEARER = require('hapi-auth-bearer-token');
const SKJ = 'GdM1WBRLARhOJY5zRDINqr5kv+b6ixNGuocbt+3tN/M5TH31/b1sHMPhDErJhy1InL+R8nGuWxeUsUMissde877VWCCoxpWNnmgdJKMKe1N8qmfvscAwL/BLkZpuj9ByMD3UDOydtl9xXsjjYniiJ2Jq3gXLhb5fSHX3XCJ05/DBvdXlkdvt54qHqSswMip6O7Gpfvqq/uH1wHH+Z6jEJhmvUAb3LgNziT9TgGUSGrT8djJFiCqdNZbx36JZeps88YjM+nGDaoyjEZoxyrTbMy6qhzjavM0Ym6Upi4Ffa99avgpXx7tLPOjmKMQd+b2z87oUSVNMy1kdrpgNidxHDA==';
const BcryptSalt = 10;
const TIME_OUT_SESSION = 30 * 60 * 1000; //30mins
const SERVER_PATH = __dirname;

var tokens = {};
// Conexion
const { Pool, Client } = require("pg");
const connectionString = 'postgresql://postgres:postgres@10.10.10.151:5432/node'
const db = new Pool({
    connectionString: connectionString,
})
//Server
const server = new HAPI.Server({
    host: '10.1.0.151',
    port: 9000,
    routes: {
        files: {
            relativeTo: './public'
        }
    }
});

// bring your own validation function
var validate = function (decoded, request, callback) {
    // do your checks to see if the person is valid
    if (!people[decoded.id]) {
        return callback(null, false);
    }
    else {
        return callback(null, true);
    }
};

const provision = async () => {
    await server.register([INERT, VISION, BEARER, AUTH_COOKIE/*,RECAPTCHA*/]);
    await server.register({
        plugin: require('yar'),
        options: {
            storeBlank: false,
            cookieOptions: {
                password: PASS_COOKIE,
                isSecure: false
            }
        }
    });
    await server.register({
        plugin: require('./plugins/database'),
        options: {
            connectionString: 'postgresql://postgres:postgres@10.10.10.151:5432/node'
        }
    });
    const cache = server.cache({ segment: 'tokens', expiresIn: 24 * 60 * 60 * 1000 });
    server.app.cache = cache;
    server.auth.strategy('api', 'bearer-access-token', {
        allowQueryToken: true,
        validate: async (request, token, h) => {
            let dToken = null;
            let isValid = false;
            let exp = tokens[token].exp;
            if (exp) {
                if (exp > (new Date().getTime())) {
                    tokens[token].exp = new Date().getTime() + TIME_OUT_SESSION;
                    try {
                        dToken = JWT.decode(token);
                        isValid = true;
                    } catch (err) {
                        console.log(err);
                    }
                } else {
                    delete tokens[token];
                }
            }
            const credentials = { dToken };
            const artifacts = { test: 'info' };
            return { isValid, /*dToken*/credentials, artifacts };
        }
    });
    server.auth.strategy('web', 'cookie', {
        password: PASS_COOKIE,
        cookie: 'sHapiJTCCIA',
        redirectTo: '/login',
        isSecure: false,
        clearInvalid: true,
        redirectOnTry: false,
        validateFunc: async (req, session) => {
            const token = await cache.get(session.token);
            const out = {
                valid: !!token
            };
            if (!out.valid) {
                return out;
            }
            let dToken = null;
            let isValid = false;
            let exp = token.exp;
            if (exp) {
                if (exp > (new Date().getTime())) {
                    //tokens[token].exp = new Date().getTime() + 30 * 60 * 1000;
                    token.exp = new Date().getTime() + TIME_OUT_SESSION;
                    cache.set(session.token, token);
                    try {
                        dToken = JWT.decode(session.token);
                        isValid = true;
                    } catch (err) {
                        console.log(err);
                    }
                } else {
                    req.cookieAuth.clear();
                    out.valid = false;
                }
            }
            out.credentials = { dToken };
            return out;
        }
    });
    server.auth.default('web');

    server.views({
        engines: { hbs: require('handlebars') },
        relativeTo: __dirname,
        path: './views',
        layout: true,
        layoutPath: './views/layout',
        partialsPath: './views/partials',
        helpersPath: './views/helpers'
    });
    server.bind({
        db: db,
        JWT: JWT,
        SKJ: SKJ,
        Bcrypt: Bcrypt,
        BcryptSalt: BcryptSalt,
        tokens: tokens,
        TIME_OUT_SESSION: TIME_OUT_SESSION,
        PATH:PATH,
        SERVER_PATH: SERVER_PATH
    });
    
    server.route(require('./src/public/routes.js'));
    server.route(require('./src/example/routes.js'));
    server.route(require('./src/auth/routes.js'));
    server.route(require('./src/pila/routes.js'));
    server.route(require('./src/impuestos/routes.js'));
    server.route(require('./src/mail/routes.js'));
    server.route(require('./src/adminImage/routes.js'));
    server.route(require('./src/generateCodeImage/routes.js'));
    server.route(require('./src/pdf/routes.js'));
    server.route(require('./src/fileValidation/routes.js'));
    server.route(require('./src/jsreports/routes.js'));
    server.route(require('./src/loadFile/routes.js'));
    server.route(require('./src/audio/routes.js'));
    server.route(require('./src/webServices/routes.js'));

    await server.start();
    console.log('Server running at:', server.info.uri);
}

provision();
