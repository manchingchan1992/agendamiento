$("input:text").click(function () {
    $(this).parent().find("input:file").click();
  });
  
  $('input[type=file]')
    .on('change', function (e) {
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      var me = this;
      reader.onload = function () {
        var fileContent = reader.result;
      }
      var name = e.target.files[0].name;
      $('input:text', $(e.target).parent()).val(name);
    });
  
  $('.ui.search')
    .search({
      apiSettings: {
        url: '/searchFile?id={query}'
      },
      fields: {
        results: 'files',
        title: 'id_file',
        description: 'name_file'
      },
      onSelect: function (results) {
        $("#name_file").val(results.name_file);
      },
      minCharacters: 1
    });
  
  function cleanInputSelect() {
    $("#name_file").val('');
  }
  
  function cleanInputLoad() {
    $("#inputFile").val('');
  }