$("input:text").click(function () {
  $(this).parent().find("input:file").click();
});

$('input[type=file]')
  .on('change', function (e) {
    var reader = new FileReader();
    reader.readAsDataURL(e.target.files[0]);
    var me = this;
    reader.onload = function () {
      var fileContent = reader.result;
    }
    var name = e.target.files[0].name;
    $('input:text', $(e.target).parent()).val(name);
  });

$('.ui.search')
  .search({
    apiSettings: {
      url: '/impuestos/searchImage?id={query}'
    },
    fields: {
      results: 'images',
      title: 'id_image',
      description: 'ref_image'
    },
    onSelect: function (results) {
      $("#name_image").val(results.ref_image);
      $("#date_load").val(results.date_load);
    },
    minCharacters: 1
  });

function cleanInputSelect() {
  $("#name_image").val('');
  $("#date_load").val('');
}

function cleanInputLoad() {
  $("#inputImage").val('');
}