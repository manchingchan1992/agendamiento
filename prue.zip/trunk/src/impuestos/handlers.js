'use strict';

exports.redirectImpuestos = function (req,res){
    let credentials = req.auth.credentials.dToken;
    if (credentials.rol === 2) {
        return res.view('impuestos', {credentials: credentials});
    }
    return res.view('unauth');
}