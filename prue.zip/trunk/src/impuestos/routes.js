'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [{
    method: 'GET',
    path: '/impuestos',
    handler: HANDLERS.redirectImpuestos
}]