'use strict';

//const QR_CODE = require('qrcode');
const BWIPJS = require('bwip-js');

/*exports.generateQR = async function (req, res) {
    let url;
    try {
        url = await QR_CODE.toDataURL(JSON.stringify('Hola soy codigo qr'));
        //console.log(url)
    } catch (err) {
        console.log("error generando qr")
    }
    return res.view('generateCodeImage/generateCodeImage', { url });
    
}*/

exports.catchDataQR = function (req, res) {
    return res.view('generateCodeImage/formDataQR');
}

exports.generateQRParams = async function (req, res) {

    let url;
    let codeType = "Código QR empresa";
    let obj = req.payload;
    let company = {
        company: obj.company,
        address: obj.address,
        phone: obj.phone
    }

    return new Promise((resolve, reject) => {
        BWIPJS.toBuffer({
            bcid:        'qrcode',       // Barcode type
            text:        JSON.stringify(company),    // Text to encode
            //scale:       10,               // 3x scaling factor
            //height:      10,              // Bar height, in millimeters
            includetext: true,            // Show human-readable text
            textxalign:  'center',        // Always good to set this
        }, function (err, png) {
            if (err) {
                console.log(err);
            } else {
                //console.log(new Buffer(png).toString('base64'));
                let base = new Buffer(png).toString('base64')
                url = "data:image/gif;base64,".concat(base);
                resolve(res.view('generateCodeImage/generateCodeImage', {  url ,codeType }));
            }
        });
    });
}

exports.generateBarcodeParams = function (req, res) {
    let url;
    let obj = req.payload;
    let codeType = "Código de barras producto";
    
    return new Promise((resolve, reject) => {
        BWIPJS.toBuffer({
            bcid:        'code128',       // Barcode type
            text:        obj.codigo,    // Text to encode
            //scale:       10,               // 3x scaling factor
            //height:      10,              // Bar height, in millimeters
            includetext: true,            // Show human-readable text
            textxalign:  'center',        // Always good to set this
        }, function (err, png) {
            if (err) {
                console.log(err);
            } else {
                console.log(png);
                //console.log(new Buffer(png).toString('base64'));
                let base = new Buffer(png).toString('base64')
                url = "data:image/gif;base64,".concat(base);
                resolve(res.view('generateCodeImage/generateCodeImage', {  url ,codeType }));
                //resolve(png);
            }
            
        });
    });
}

exports.catchDataCodeBar = function (req, res) {
    return res.view('generateCodeImage/formDataCodeBar');
}




/*exports.generateQR = function (req,res){
    let url;
    this.QR_CODE.toDataURL('I am a pony!', function (err, url) {
        if(err){
            console.log("error generando qr")
        }
        console.log(url)
      })
    return url; 
}*/