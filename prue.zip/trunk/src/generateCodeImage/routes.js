'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [/*{
    method: 'GET',
    path: '/generateCodeQR',
    config: { auth: false },
    handler: HANDLERS.generateQR
},*/{
    method: 'GET',
    path: '/formCodeQR',
    handler: HANDLERS.catchDataQR
},{
    method: 'POST',
    path: '/generateCodeQRParams',
    handler: HANDLERS.generateQRParams
},{
    method: 'GET',
    path: '/formBarCode',//https://github.com/lindell/JsBarcode
    handler: HANDLERS.catchDataCodeBar
},
{
    method: 'POST',
    path: '/generateBarCodeParams',
    handler: HANDLERS.generateBarcodeParams
    
}]