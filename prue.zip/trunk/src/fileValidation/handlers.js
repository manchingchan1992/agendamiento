'use strict';

const PATH = require('path');
const FS = require('fs');
const READLINE = require('linebyline');
const JOI = require('joi');
const SCHEMAS = require('./schemasJoi');

const PLANTILLA = {
    "registroTipoUno": [{
        "campo": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22],
        "long": [2, 1, 4, 200, 2, 16, 1, 1, 10, 10, 1, 10, 40, 6, 7, 7, 10, 10, 5, 12, 2, 2],
        "posicion": [{
            "inicial": [1, 3, 4, 8, 208, 210, 226, 227, 228, 238, 248, 249, 259, 299, 305, 312, 319, 329, 339, 344, 356, 358],
            "final": [2, 3, 7, 207, 209, 225, 226, 227, 237, 247, 248, 258, 298, 304, 311, 318, 328, 338, 343, 355, 357, 359]
        }],
        "tipo": ["N", "N", "N", "A", "A", "A", "N", "A", "N", "A", "A", "A", "A", "A", "A", "A", "N", "A", "N", "N", "N", "N"]
    }],
    "registroTipoDos": [{
        "campo": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97],
        "long": [2, 5, 2, 16, 2, 2, 1, 1, 2, 3, 20, 30, 20, 30, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 6, 6, 6, 6, 6, 2, 2, 2, 2, 9, 1, 9, 9, 9, 9, 7, 9, 9, 9, 9, 9, 9, 9, 7, 9, 9, 15, 9, 15, 9, 9, 9, 9, 7, 9, 7, 9, 7, 9, 7, 9, 7, 9, 2, 16, 1, 6, 1, 1, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 9, 3, 10],
        "posicion": [{
            "inicial": [],
            "final": []
        }],
        "tipo": []
    }]
}

exports.fileValidation = async function (req, res) {
    let credentials = req.auth.credentials.dToken;
    let obj = req.payload;
    let public_tmp_path = this.SERVER_PATH + "/public/tmp";
    let fileValidationPath = public_tmp_path + "/filesValidations"
    let dateValidationPath = fileValidationPath + "/" + await formatDate(new Date());
    let resultValidation = new Array();
    let fileObject;

    if (FS.existsSync(public_tmp_path)) {
        rmDir(public_tmp_path);
    }

    FS.mkdirSync(public_tmp_path); //creación rutas
    FS.mkdirSync(fileValidationPath);
    FS.mkdirSync(dateValidationPath);
    FS.writeFileSync(dateValidationPath + "/" + obj.nameFile, obj.fileTxt); //Almacena Archivo

    let rl = READLINE(dateValidationPath + "/" + obj.nameFile);
    let fileObj = new Object();

    fileObject = await new Promise(resolve => {
        rl.on('line', function (line, lineCount, byteCount) {
            //console.log(line);
            resolve(buildObject(line, fileObj)); //temporal ¿cuando son mas lineas?
        })
            .on('error', function (e) {
                console.log("esto es errot" + e);
            });
    });


    // validacion sencilla
    /*let numero = "01";
    resultValidation= await checkNumber(numero);*/


    resultValidation.push(await checkRegTipoUno(fileObject.regTipoUno, SCHEMAS.fileJoiSchemaRegTipoUno, res));

    for (var i = 0; i < fileObject.regTipoDos.length; i++) {
        resultValidation.push(await checkRegTipoDos(fileObject.regTipoDos[i], SCHEMAS.fileJoiSchemaRegTipoDos, res));
    }


    return res.view('fileValidations/showResult', { credentials: credentials, resultValidation });
}

exports.fileUpload = function (req, res) {
    return res.view('fileValidations/fileUpload');
}

var rmDir = function (dirPath) {
    try { var files = FS.readdirSync(dirPath); }
    catch (e) { return; }
    if (files.length > 0)
        for (var i = 0; i < files.length; i++) {
            var filePath = dirPath + '/' + files[i];
            if (FS.statSync(filePath).isFile())
                FS.unlinkSync(filePath);
            else
                rmDir(filePath);
        }
    FS.rmdirSync(dirPath);
};

function formatDate(date) {
    var day = date.getDate();
    var month = date.getMonth();
    var year = date.getFullYear();

    return day + '-' + month + '-' + year;
}


var buildObject = function (line, fileObj) {
    //let miObjeto = new Object();
    let tamanioPlantillaReg1 = PLANTILLA.registroTipoUno[0].campo.length;
    let objPlantillaReg1 = PLANTILLA.registroTipoUno[0];
    let tamanioPlantillaReg2 = PLANTILLA.registroTipoDos[0].campo.length;
    let objPlantillaReg2 = PLANTILLA.registroTipoDos[0];
    //let array = new Array();
    let inicial = 0;
    let final = 0;
    let campos = new Object();

    if (line.substring(0, 2) === '01') {
        campos[1] = line.substring(0, objPlantillaReg1.long[0]);
        inicial = objPlantillaReg1.long[0];

        for (var i = 1; i < tamanioPlantillaReg1; i++) {
            final = inicial + objPlantillaReg1.long[i];
            //array.push(line.substring(inicial, final));
            campos[i + 1] = line.substring(inicial, final);
            inicial = final;
        }
        fileObj.regTipoUno = campos;

    } else {
        if (fileObj.regTipoDos === undefined) {
            let array = new Array();
            fileObj.regTipoDos = array;
        }

        campos[1] = line.substring(0, objPlantillaReg2.long[0]);
        inicial = objPlantillaReg2.long[0];

        let tamanioPlantillaReg2 = PLANTILLA.registroTipoDos[0].campo.length;
        for (var i = 1; i < tamanioPlantillaReg2; i++) {
            final = inicial + objPlantillaReg2.long[i];
            //array.push(line.substring(inicial, final));
            campos[i + 1] = line.substring(inicial, final);
            inicial = final;
        }
        fileObj.regTipoDos.push(campos);
    }
    return fileObj;
}

let checkRegTipoUno = async function (fileObject, schema) {
    let validation;
    return validation = await new Promise(resolve => {
        JOI.validate(fileObject, schema, (err, value) => {
            if (err) {
                console.log("errorres " + err);
                resolve(err);
            } else {
                resolve("Correcto");
            }
        });
    })
}

let checkRegTipoDos = async function (fileObject, schema) {
    let validation;
    return validation = await new Promise(resolve => {
        JOI.validate(fileObject, schema, (err, value) => {
            if (err) {
                console.log("errorres " + err);
                resolve(err);
            } else {
                resolve("Correcto");
            }
        });
    })
    //console.log("Validation success");

}
