'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [
{
    method: 'GET',
    path: '/uploadFileValidation',
    handler: HANDLERS.fileUpload
    
},{
    method: 'POST',
    path: '/fileValidation',
    handler: HANDLERS.fileValidation
    
}]

