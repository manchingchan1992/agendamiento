'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [
    {
        method: 'GET',
        path: '/menuAudio',
        handler: HANDLERS.menuAudioView
    },
    {
        method: 'GET',
        path: '/showAudio',
        handler: HANDLERS.showAudioView
    },
    {
        method: 'POST',
        path: '/audio/download',
        handler: HANDLERS.downloadAudio
    }
]