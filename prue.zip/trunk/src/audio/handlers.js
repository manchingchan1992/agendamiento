'use strict';

exports.menuAudioView = function (req, res) {
    let credentials = req.auth.credentials.dToken;
    return res.view('impuestos', { audio: 1, credentials: credentials });
}

exports.showAudioView = async function (req, res) {
    let credentials = req.auth.credentials.dToken;
    let query = {
        name: 'fetch-calls',
        text: "select id_call, to_char(date_call, 'dd-mm-yyyy HH24:MI:SS') date_call, duration, subject, response, resolved, audio, calls.user, username from calls inner join users on calls.user = users.id order by date_call asc",
        values: []
    }
    let options = { credentials: credentials }
    try {
        let calls = await this.db.query(query);
        options.calls = calls.rows;
    } catch (err) {
        console.log(err);
        options.calls = [];
    }
    return res.view('audio/showAudio', options);
}

exports.downloadAudio = function (req, res){
    let credentials = req.auth.credentials.dToken;
    let data = req.payload;
    console.log('../'+data.audioValue);
    return res.file('../'+data.audioValue, {
        mode: 'attachment',
        filename: 'audio.wav'
    });
}