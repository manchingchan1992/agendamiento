'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [{
    method: 'GET',
    path: '/',
    config: {
        auth: {
            strategy: 'web',
            mode: 'try'
        }
    },
    handler: HANDLERS.home
}, {
    method: 'GET',
    path: '/public/{param*}',
    config: { auth: false },
    handler: {
        directory: {
            path: '..',
        }
    }
}]