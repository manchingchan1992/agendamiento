'use strict';

exports.home = async (req,res) => {
    let credentials = {rol: 0};
    if (req.auth.isAuthenticated) {
        credentials = req.auth.credentials.dToken;
    }
    return res.view('home',{credentials: credentials});
}