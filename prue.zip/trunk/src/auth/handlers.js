'use strict';

const CAPTCHA = require('svg-captcha');

exports.WebCheckLogin = async function (req, res) {
    try {
        let obj = req.payload;
        let captchaOri = req.yar.get('captcha').key;

        if (captchaOri != obj.captcha) {
            req.yar.set('error', { key: 'No coincide el código captcha' });
            return res.redirect('/login');
        }
        req.yar.clear('captcha');
        obj.password = Buffer.from(obj.password, 'base64').toString();
        if (req.auth.isAuthenticated) {
            return res.redirect('/');
        }
        let dbUser = await queryUser(this.db,obj.username);
        if (!dbUser) {
            req.yar.set('error', { key : 'Usuario o contraseña inválida' });
            return res.redirect('/login');
        }
        let passOk = await this.Bcrypt.compare( obj.password, dbUser.password);
        if (passOk) {
            let session = {
                valid: true, // this will be set to false when the person logs out
                id: dbUser.id, // a random session id
                name: dbUser.name,
                username: dbUser.username,
                rol: dbUser.rol
            }
            let token = this.JWT.sign(session, this.SKJ);
            //this.tokens[token] = { username: session.username, exp: new Date().getTime() + 30 * 60 * 1000 };
            await req.server.app.cache.set(token, { username: session.username, exp: new Date().getTime()+ this.TIME_OUT_SESSION }, 0);
            await storeLoginLog(this.db,dbUser.id,req);
            req.cookieAuth.set({ token });
            req.auth.isAuthenticated = true;
            req.yar.clear('error');
            return res.redirect('/');
        } else {
            req.yar.set('error', { key : 'Usuario o contraseña inválida' });
            return res.redirect('/login');
        }
    } catch (error) {
        return error;
    }
}

exports.ApiCheckLogin = async function (req, res) {
    try {
        let obj = req.payload
        if (checkSession(this.tokens,obj)) {
            return "Ya tiene una sesión activa";
        }
        let dbUser = await queryUser(this.db,obj.username);
        let passOk = await this.Bcrypt.compare( obj.password, dbUser.password);
        if (passOk) {
            let session = {
                valid: true, // this will be set to false when the person logs out
                id: dbUser.id, // a random session id
                name: dbUser.nombre,
                username: dbUser.username,
                rol: dbUser.rol
            }
            let token = this.JWT.sign(session, this.SKJ);
            this.tokens[token] = { username: session.username, exp: new Date().getTime() + this.TIME_OUT_SESSION };
            return token;
        } else {
            return "Password incorrecto";
        }
    } catch (error) {
        return error;
    }
}

exports.checkLoginView = function (req, res) {
    let error = req.yar.get('error');
    if (req.auth.isAuthenticated) {
        return res.redirect('/');
    }
    var captcha = CAPTCHA.create({
        size: 6,
        noise: 3
    });
    req.yar.set('captcha', { key: captcha.text });
    if (error) {
        req.yar.clear('error');
        return res.view('signin', { credentials: { rol: 0 }, captcha: captcha.data, error: error.key });
    }
    return res.view('signin', { credentials: { rol: 0 }, captcha: captcha.data });
}

exports.registerUser= async function (req, res){
    let obj = req.payload;
    obj.password = await this.Bcrypt.hash(obj.password, this.BcryptSalt);
    let user={
        username : obj.username,
        name : obj.name,
        password : obj.password,
        email: obj.email,
        rol : 1
    }
    await createUser(this.db,user);
    return req.payload;
}

exports.registerUserView = function (req,res){
    return res.view('signup', {});
}

exports.webLogout = (req,res) => {
    req.cookieAuth.clear();
    return res.redirect('/');
};

function checkSession(tokens,obj) {
    //const cached = await cache.get(session.sid);
    for (var key in tokens) {
        if (obj.username === tokens[key].username) {
            if (tokens[key].exp > (new Date().getTime())) {
                return true;
            } else {
                delete tokens[key];
                break;
            }
        }
    }
    return false;
}
async function queryUser(db,userName) {
    let query = {
        name: 'fetch-user',
        text: 'SELECT name,id,password,rol,username FROM users WHERE username = $1',
        values: [userName]
    }
    return (await db.query(query)).rows[0];
}

async function createUser(db,user) {
    let query = {
        name: 'fetch-user',
        text: 'INSERT INTO users(username,name,password,email,rol) VALUES($1,$2,$3,$4,$5)',
        values: [user.username,user.name,user.password,user.email,user.rol]
    }
    try {
        await db.query(query);
    } catch (err) {
        console.log(err);
    }
}

async function storeLoginLog(db,user_id,req) {
    let query = {
        name: 'store-login-log',
        text: 'INSERT INTO login_log(user_id,date,ip,browser) VALUES($1,now(),$2,$3)',
        values: [user_id,req.info.remoteAddress,req.headers['user-agent']]
    }
    try {
        await db.query(query);
    } catch (err) {
        console.log(err);
    }
}
