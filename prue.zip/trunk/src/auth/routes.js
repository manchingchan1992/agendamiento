'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [{
    method: 'POST',
    path: '/api/login',
    config: { auth: false },
    handler: HANDLERS.ApiCheckLogin
}, {
    method: 'POST',
    path: '/web/login',
    config: {
        auth: {
            strategy: 'web',
            mode: 'try'
        }
    },
    handler: HANDLERS.WebCheckLogin
}, {
    method: 'POST',
    path: '/signup',
    config: { auth: false },
    handler: HANDLERS.registerUser
}, {
    method: 'GET',
    path: '/signup',
    config: { auth: false },
    handler: HANDLERS.registerUserView
}, {
    method: 'GET',
    path: '/login',
    config: {
        auth: {
            strategy: 'web',
            mode: 'try'
        }
    },
    handler: HANDLERS.checkLoginView
}, {

    method: 'GET',
    path: '/web/logout',
    handler: HANDLERS.webLogout
}]