'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [{
    method: 'GET',
    path: '/jsreports/test',
    config: { auth: false },
    handler: HANDLERS.test
},{
    method: 'GET',
    path: '/jsreports/login_log',
    handler: HANDLERS.reportLoginsLogView
},{
    method: 'POST',
    path: '/jsreports/login_log',
    handler: HANDLERS.reportLoginsLog
}]