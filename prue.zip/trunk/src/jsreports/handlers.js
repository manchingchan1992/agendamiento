'use strict';

/*const CONFIG = {
    baseUrl: 'http://10.0.0.12:8180/jasperserver/',
    userName: 'osticket',
    password: 'master',
    headers: { authorization: 'Basic b3N0aWNrZXQ6bWFzdGVy', accept: 'application/json' }
}

const JASPER = require('jasper-node-client')(CONFIG)*/

/*exports.mailView = function (req, res) {
    let credentials = req.auth.credentials.dToken;
    return res.view('mail', { credentials: credentials });
}*/

//const JASPER = require("./JasperConnector");

//const PDF = require('handlebars-pdf');
const HBS = require('handlebars');
const PDF = require('html-pdf');
const FS = require('fs');

exports.test = async function (req, res) {
    /*let jasper = new JASPER();
    let reportPath = 'Reports/osticket/';
    let reportName = 'Reporte_Ticket_Servicios_TSOA';
    let fileFormat = 'pdf';
    let params = {
        Fecha_Inicial: '02-05-2018', //'2017-11-01%2000:00:00',
        Fecha_Final: '02-06-2018', //'2017-11-30%2000:00:00',
        Departamentos_Servicios_TSOA: '6'
    }
    return new Promise(resolve => {
        jasper.requestReport(reportPath, reportName, fileFormat, params, (err, response, headers) => {
            if (err != null) {
                console.log(err)
                resolve("FAIL");
            } else {
                //res.writeHead(200, headers) //res is express response object
                //res.end(response) //response (this is Jasper Client response object passed to the callback) contains the buffer returned by Jasper Server.
                console.log(headers);
                console.log(response);
                resolve(response);
            }
        });
    });*/
    /*let jasper = new JASPER({
        url: "http://10.0.0.12:8180/jasperserver/",
        loginPath: "j_spring_security_check",
        rootPathReports: "Reports/osticket/",
        credentials: {
            user: "osticket",
            pass: "master"
        }
    });
    await jasper.login();
    let params = {
        Fecha_Inicial: '02-05-2018', //'2017-11-01%2000:00:00',
        Fecha_Final: '02-06-2018', //'2017-11-30%2000:00:00',
        Departamentos_Servicios_TSOA: '6',
        RUN_OUTPUT_FORMAT: "PDF"
    }
    let stream = require('stream').Writable;
    jasper.getReport('Reporte_Ticket_Servicios_TSOA', params, stream);
    return "ok";
    */
    let reportPath = "test-"+Math.random()+".pdf";
    let document = {
        template: '<h1>{{msg}}</h1>'+
        '<p style="color:red">Red text</p>'+
        '<img src="{{uri}}/public/img/logo.png"/>',
        context: {
            uri: req.server.info.uri,
            msg: 'Hello world'
        },
        path: "./public/reportTmp/"+reportPath
    };
    await PDF.create(document);
    return res.file("reportTmp/"+reportPath, {
        mode: 'attachment'
    });
}

exports.reportLoginsLogView = function (req, res) {
    let credentials = req.auth.credentials.dToken;
    return res.view('reports/login_logs', {credentials: credentials});
}

exports.reportLoginsLog = async function (req, res) {
    let credentials = req.auth.credentials.dToken;
    let fechaIni = new Date(req.payload.date);
    let fechaFin = new Date(fechaIni.getTime() + 86400000);
    //console.log(fechaIni.toISOString().slice(0, 19).replace('T', ' '));
    //console.log(fechaFin.toISOString().slice(0, 19).replace('T', ' '));
    let reportName = "reportLogLogins-"+Math.round(Math.random()*1000000)+".pdf";
    let query = {
        text: 'SELECT id, name, username FROM users'
    }
    let users = (await this.db.query(query)).rows;
    for (let i = users.length - 1; i>-1; i--) {
        let query = {
            text: 'SELECT * FROM login_log WHERE user_id=$1 AND date BETWEEN $2 AND $3',
            values: [users[i].id, fechaIni, fechaFin]
        }
        users[i].logins = (await this.db.query(query)).rows;
        if(users[i].logins.length == 0){
            users.splice(i, 1);
        }
    }
    if (users.length == 0) {
        return res.view('reports/login_logs', {credentials: credentials, notFound: "No se encontraron registros para esta fecha"});
    }
    let source = FS.readFileSync(__dirname + '/reports/example.hbs', 'utf8');
    let template = HBS.compile(source);
    let mounths = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
    let context = {
        uri: req.server.info.uri,
        users: users,
        date: fechaIni.getDate() + " de " + mounths[fechaIni.getMonth()] + " del " + fechaIni.getFullYear()
    };
    let options = {
        format: "Letter",
        orientation: "portrait",
        border: {
            top: "1cm",
            right: "1cm",
            bottom: "1cm",
            left: "0.5cm"
        }
    };
    return new Promise(resolve => {
        let html = template(context);
        PDF.create(html, options).toFile("./public/reportTmp/"+reportName, function(err, file){
            if (err) {
                console.log(err);
                resolve(err);
            }
            resolve(res.file("reportTmp/"+reportName, {
                mode: 'attachment'
            }));
        });
    })
}