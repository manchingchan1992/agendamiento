'use strict';

const request = require('request');

class JasperConnector {

    constructor(serverConfig) {
        this.serverConfig = serverConfig;
        this.credentials = serverConfig.credentials;
        //this.loginPath = this.serverConfig.url + this.serverConfig.loginPath;
        this.loginPath = this.serverConfig.url + "rest/login/";
        this.APIPath = this.serverConfig.url + "rest/report/";
        this.reportsPath = this.APIPath + this.serverConfig.rootPathReports;
        this.lastLogin;
        this.cookie;
    }

    login() {
        let isCookieValid = false;

        if (this.lastLogin) {
            let now = new Date();
            let diff = Math.ceil((now.getTime() - this.lastLogin.getTime()) / 1000);
            console.log(diff);
            isCookieValid = diff < this.serverConfig.loginTimeOut ? true : false; // If the difference between date1 and date2 is 2 minuts
        }

        return new Promise((resolve, reject) => {
            let options = {
                url: this.loginPath,
                Accept: 'application/json',
                qs: {
                    j_username: this.credentials.user,
                    j_password: this.credentials.pass
                }
            };
            if (!isCookieValid) {
                request.post(options, (err, resp, body) => {
                    if (err) {
                        console.log(err);
                        reject(err);
                    } else {
                        this.cookie = resp.headers['set-cookie'][0];
                        //this.cookie.shift();
                        //this.cookie = "$Version=0; " + this.cookie.replace('P', "$P");
                        this.cookie = "Version=0; " + this.cookie;
                        this.lastLogin = new Date();
                        console.log(this.cookie);
                        resolve(this.cookie);
                    }
                });
            } else {
                this.lastLogin = new Date();
                resolve(this.cookie);
            }
        });
    }

    async getReport(reportName, params = null, streamWritable) {
        let uuid = await this.getUUID(reportName, params.RUN_OUTPUT_FORMAT);
        let fullPath = this.reportsPath + reportName;// + ".pdf";
        console.log(fullPath);
        let options = {
            url: fullPath,
            headers: {
                Accept: 'application/json',
                Cookie: this.cookie
            },
            qs: params
        };
        //let data = request.get(options);
        //console.log(data);
        //data.pipe(data2);
        /*request.get(fullPath, options)
            .on('response', function (resp) {
                console.log('RESP', resp.statusCode);
            })
            .pipe(streamWritable);*/
        
        return new Promise((resolve, reject) => {
            request.post(options, (err, resp, body) => {
                console.log("response");
                console.log(body);
                if (err) {
                    console.log(err);
                    reject(err);
                } else {
                    //this.cookie = resp.headers['set-cookie'];
                    //this.lastLogin = new Date();
                    //resolve(this.cookie);
                    console.log(resp);
                    let data = resp.read();
                    console.log(data);
                    resolve("ok");
                }
            });
        });
    }

    getUUID(reportName, format) {
        let fullPath = this.reportsPath + reportName;
        //let fullPath = this.APIPath + reportName;
        console.log(fullPath);
        let options = {
            url: fullPath,
            headers: {
                Accept: 'application/json',
                Cookie: this.cookie,
                Authorization: "Basic " + new Buffer(this.credentials.user+":"+this.credentials.pass).toString('base64')
            },
            qs: {
                RUN_OUTPUT_FORMAT: format
            }
        };
        return new Promise(resolve => {
            request.put(options, (err, resp, body) => {
                console.log("UUID");
                console.log(body);
                resolve("hay caramba");
            });
        })
    }
}

module.exports = JasperConnector;