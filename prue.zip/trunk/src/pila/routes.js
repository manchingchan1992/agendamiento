'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [{
    method: 'GET',
    path: '/pila',
    handler: HANDLERS.redirectPila
}]