'use strict';

exports.redirectPila = function (req,res){
    let credentials = req.auth.credentials.dToken;
    if (credentials.rol === 3) {
        return res.view('pila', {credentials: credentials});
    }
    return res.view('unauth');
}