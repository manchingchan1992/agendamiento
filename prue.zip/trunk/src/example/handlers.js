'use strict';

exports.helloWorld = (request, reply) => {
    return 'Hello, world!';
}

exports.sayHello = (request, reply) => {
    return 'Hello, ' + encodeURIComponent(request.params.name) + '!';
}

exports.showUsers = (request, reply) => {
    const users = [{
        name: 'Ana Contreras',
        cc: '124.545.745',
        tel: '310 2457841'
    },{
        name: 'Andres Gutierres',
        cc: '35.325.684',
        tel: '316 4569878'
    },{
        name: 'Pepe Perez',
        cc: '123.456.789',
        tel: '315 5555555'
    }];

    return reply.view('index',{
        users: users,
        someText: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque aliquam, ex nec semper tempus, sapien mauris tincidunt dolor, ut lobortis libero ipsum pharetra elit. In hac habitasse platea dictumst. Morbi tincidunt purus aliquet, accumsan nibh ut, malesuada velit. In aliquet magna eu odio lobortis, id facilisis enim lacinia. Proin congue pretium fringilla. Duis posuere mauris a erat venenatis tristique. Sed volutpat volutpat vestibulum. Quisque congue faucibus interdum. Donec pharetra dui finibus faucibus scelerisque.\n\n\
        Duis semper facilisis quam. Aliquam in metus magna. Integer non dictum elit. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Integer tempus commodo tempus. In dapibus metus ut gravida hendrerit. Fusce eget auctor mi. Sed scelerisque neque ut velit commodo mattis. Aenean sagittis gravida luctus. Curabitur nibh lectus, hendrerit nec finibus nec, porttitor in nisl. In mollis augue erat, imperdiet commodo risus efficitur eget. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nam interdum mi at urna accumsan, non iaculis velit condimentum. Phasellus condimentum venenatis mauris ac ultricies.\n\n\
        Mauris vitae mi elit. Nullam aliquet sed purus et tristique. Mauris a tincidunt ex, non pretium orci. Nullam pulvinar suscipit rutrum. Aliquam laoreet, leo eu venenatis tristique, urna elit ultricies neque, in dictum sem ante porta mauris. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam condimentum odio magna, quis vulputate magna aliquet eu. Donec id commodo enim. Nam vestibulum ultricies neque sit amet scelerisque. Pellentesque viverra sodales eros, vitae sagittis orci consequat venenatis. Quisque varius nibh sit amet condimentum tincidunt.\n\n\
        Nunc eget mi ante. Mauris eu tempus diam. Vestibulum est ante, consequat sit amet maximus ut, porttitor ac enim. Ut viverra sem eget felis convallis, ut feugiat nisi eleifend. Vivamus in pulvinar elit, quis luctus tellus. Pellentesque porta posuere tincidunt. Quisque vitae elementum purus. Proin eget faucibus elit.\n\n\
        Y aqui un poco de texto malisioso <script>$alert("script injection")</script> <h1>buuu</h1>'
    });
}