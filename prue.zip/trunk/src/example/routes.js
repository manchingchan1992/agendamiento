'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [{
    method: 'GET',
    path: '/sayhello/{name}',
    handler: HANDLERS.sayHello
}, {
    method: 'GET',
    path: '/hello',
    //config: { auth: 'jwt' },
    handler: {
        file: 'hello.html'
    }
}, {
    method: 'GET',
    path: '/users',
    handler: HANDLERS.showUsers
}]