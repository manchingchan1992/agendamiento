'use strict';

const controller = require('./handlers') // Archivo .js con las rutas

module.exports = [
    {
        method: 'GET',
        path: '/user-nombre/{nombre}',
        config: { auth: 'api' },
        handler: controller.consultarUserName // recibe codigo artista a consultar
    },
    {
        method: 'GET',
        path: '/search-users',
        config: { auth: 'api' },
        handler: controller.consultarUsers  // Consulta todos los artistas
    }
]