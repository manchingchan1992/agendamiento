'use strict';

exports.consultarUserName = async function consultarUserName(request, reply) {
    try {
        const obj = request.params//
        const consulta = {
            
            name: 'fetch-artistas',
            text: 'SELECT * FROM users WHERE name = $1',
            values: [obj.nombre]
        }
        var res = await this.db.query(consulta)
        return res.rows;
    } catch (error) {
        return error;
    }
}


exports.consultarUsers = async function consultarUsers(request, reply) {
    try {
        //const obj = request.payload
        const consulta = {
            name: 'fetch-artistas',
            text: 'SELECT * FROM users',
            values: []
        }
        var res = await this.db.query(consulta);
        return res.rows;
    } catch (error) {
        return error;
    }
}

