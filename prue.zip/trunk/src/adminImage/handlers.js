'use strict';
const FS = require('fs');
const DATE_FORMAT = require('dateformat');
const PATH_IMAGE = __dirname + "/../../public/img/";
const RELATIVE_PATH_IMAGE = "/public/img/";
const DATE = DATE_FORMAT(new Date(), 'ddmmyyyy');

exports.loadImage = function (req, res) {
    let credentials = req.auth.credentials.dToken;
    if (credentials.rol === 2) {
        let message = req.yar.get('message');
        if (message) {
            req.yar.clear('message');
            return res.view('adminImage/loadImage', { message: message.key, credentials: credentials });
        }
        return res.view('adminImage/loadImage', { credentials : credentials});
    }
    return res.view('unauth');
}

exports.downloadImage = function (req, res) {
    let credentials = req.auth.credentials.dToken;
    return res.view('adminImage/downloadImage', { credentials : credentials});
}

exports.menuTax = async function (req, res) {
    let credentials = {rol : 0};
    if(req.auth.isAuthenticated){
        credentials = req.auth.credentials.dToken;
    }
    return res.view('impuestos', { impuestos: 1, credentials : credentials });
    
}


exports.download = function (req, res) {
    let data = req.payload;
    return res.file("../" + RELATIVE_PATH_IMAGE + "/" + DATE + "/" + data.name_image, {
        mode: 'attachment',
        filename: data.name_image
    });
}

exports.search = async function (req, res) {
    let query = {
        name: 'fetch-images',
        text: "SELECT id_image, ref_image, to_char(date_load, 'yyyymmdd') as date_load FROM images Where to_char(id_image, '999') like $1",
        values: ["%" + req.query.id + "%"]
    }
    try {
        let images = await this.db.query(query);
        return { images: images.rows };
    } catch (err) {
        console.log(err);
        return { images: [] };
    }
}

exports.showImage = function (req, res) {
    let srcImage = req.yar.get('srcImage');
    let credentials = req.auth.credentials.dToken;
    if (srcImage) {
        req.yar.clear('srcImage');
        return res.view('adminImage/showImage', { srcImage: srcImage.key, credentials : credentials });
    }
    return res.view('adminImage/showImage', { credentials : credentials });
}

exports.saveImage = async function (req, res) {
    let data = req.payload;
    let urlRedirect = '/impuestos/showImage';
    let options = {};
    try {

        let tempPath = PATH_IMAGE + DATE;
        if (!FS.existsSync(tempPath)) {
            FS.mkdirSync(tempPath);
        }

        let fullPath = tempPath + "/" + data.file.hapi.filename;

        if (!FS.existsSync(fullPath)) {
            let file = FS.createWriteStream(fullPath);
            data.file.pipe(file);
            await uploadImage(this.db, data.file.hapi.filename);
            req.yar.set('srcImage', { key: RELATIVE_PATH_IMAGE + DATE + "/" + data.file.hapi.filename });
        } else {
            urlRedirect = '/impuestos/loadImage';
            req.yar.set('message', { key: 'La imágen ya se encuentra registrada para la fecha' });
        }
    } catch (err) {
        console.log(err);
        urlRedirect = '/impuestos/loadImage';
        req.yar.set('message', { key: 'Ocurrió un error mientras se cargaba la imágen. ' + err });
    }
    return res.redirect(urlRedirect);
}

async function uploadImage(db, path) {
    let query = {
        name: 'fetch-images',
        text: 'INSERT INTO images(ref_image, date_load ) VALUES( $1, $2 )',
        values: [path, new Date()]
    }
    try {
        await db.query(query);
    } catch (err) {
        console.log(err);
    }
}
