'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [{
    method: 'GET',
    path: '/impuestos/loadImage',
    handler: HANDLERS.loadImage
},
{
    method: 'POST',
    path: '/saveImage',
    config: {
        payload: {
            maxBytes: 209715200,
            output: 'stream',
            parse: true
        }
    },
    handler: HANDLERS.saveImage
},
{
    method: 'GET',
    path: '/impuestos/showImage',
    handler: HANDLERS.showImage
},
{
    method: 'GET',
    path: '/impuestos/downloadImage',
    handler: HANDLERS.downloadImage
},
{
    method: 'GET',
    path: '/impuestos/searchImage',
    config: { auth: false },
    handler: HANDLERS.search
},
{
    method: 'POST',
    path: '/download',
    config: { auth: false },
    handler: HANDLERS.download
},
{
    method: 'GET',
    path: '/impuestos/menuTax',
    handler: HANDLERS.menuTax
}
]