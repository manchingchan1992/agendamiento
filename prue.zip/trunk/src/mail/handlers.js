'use strict';

const NODE_MAILER = require('nodemailer');
const FS = require('fs');
const HBS = require('handlebars');

exports.mailView = function (req,res){
    let credentials = req.auth.credentials.dToken;
    return res.view('mail', {credentials: credentials});
}

exports.mailSend = async function (req,res) {
    let credentials = req.auth.credentials.dToken;
    let subject = req.payload.subject;
    let body = req.payload.body;
    let name = req.payload.name;
    let email = req.payload.email;
    let transporter = NODE_MAILER.createTransport({
        host: '10.0.11.31',
        port: 25,
        secure: false,
        requireTLS: true,
        auth: {
            user: 'noreply@jtccia.com',
            pass: 'noreply'
        },
        tls: {
            rejectUnauthorized: false
        }
    });

    let template;
    try {
        await transporter.verify;
        let source = FS.readFileSync(__dirname + '/mailTemplates/hello.hbs', 'utf8');
        template = HBS.compile(source);
    } catch (err) {
        return console.log(err);
    }

    let mailOptions = {
        from: '"Equipo de desarrollo Nodejs" <noreply@jtccia.com>',
        to: email,
        subject: subject,
        html: template({name: name, body: body})
    };
    await transporter.sendMail(mailOptions);
    return res.view('mail', {credentials: credentials, ok:'ok'});
}

exports.massMailView = function (req,res){
    let credentials = req.auth.credentials.dToken;
    return res.view('mass_mail', {credentials: credentials});
}

exports.massMailSend = async function (req,res) {
    let credentials = req.auth.credentials.dToken;
    let subject = req.payload.subject;
    let body = req.payload.body;
    let transporter = NODE_MAILER.createTransport({
        host: '10.0.11.31',
        port: 25,
        secure: false,
        requireTLS: true,
        auth: {
            user: 'noreply@jtccia.com',
            pass: 'noreply'
        },
        tls: {
            rejectUnauthorized: false
        }
    });

    let template;
    try {
        await transporter.verify;
        let source = FS.readFileSync(__dirname + '/mailTemplates/hello.hbs', 'utf8');
        template = HBS.compile(source);
    } catch (err) {
        return console.log(err);
    }

    let mailOptions = {
        from: '"Equipo de desarrollo Nodejs" <noreply@jtccia.com>',
        subject: subject
    };

    let query = {
        text: 'SELECT name,email FROM users',
    }
    let recipients = await this.db.query(query);
    recipients.rows.forEach(recipient => {
        mailOptions.to = recipient.email;
        mailOptions.html = template({name: recipient.name, body: body});
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return console.log(error);
            }
        });
    });
    return res.view('mass_mail', {credentials: credentials, ok:'ok'});
}

exports.directory = async function (req,res) {
    let query = {
        text: "SELECT name,email FROM users WHERE lower(name) LIKE $1",
        values: ["%"+req.query.q.toLowerCase()+"%"]
    }
    try {
        let users = await this.db.query(query);
        return {users: users.rows};
    } catch (err) {
        console.log(err);
        return {users: []};
    }
}