'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [{
    method: 'GET',
    path: '/mail',
    handler: HANDLERS.mailView
},{
    method: 'POST',
    path: '/mail',
    handler: HANDLERS.mailSend
},{
    method: 'GET',
    path: '/massmail',
    handler: HANDLERS.massMailView
},{
    method: 'POST',
    path: '/massmail',
    handler: HANDLERS.massMailSend
},{
    method: 'GET',
    path: '/mail/directory',
    handler: HANDLERS.directory
}]