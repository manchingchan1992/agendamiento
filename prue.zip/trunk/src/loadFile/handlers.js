'use strict';

const PATH_FILE = 'public/file';
const XML_TO_JSON = require('xml2json');
const FS = require('fs');
const XLSX = require('node-xlsx');
const EXCEL_BUILD = require('msexcel-builder');

exports.loadInputView = function (req, res) {
    let credentials = req.auth.credentials.dToken;
    return res.view('impuestos', { embargos: 1, credentials: credentials });
}

exports.uploadFIleView = function (req, res) {
    let credentials = req.auth.credentials.dToken;
    let message = req.yar.get('message');
    if (message) {
        req.yar.clear('message');
        return res.view('loadFile/uploadFile', { message: message.key, credentials: credentials });
    }
    return res.view('loadFile/uploadFile', { credentials: credentials });
}

exports.processFile = async function (req, res) {
    let credentials = req.auth.credentials.dToken;
    let data = req.payload;
    let nameFile = data.fileInput.hapi.filename;
    let ext = nameFile.split(".");
    let extension = ext[ext.length - 1];
    let download = false;
    let nameFileTxt = ext[0] + ".txt";
    switch (extension.toUpperCase()) {
        case 'TXT':
            if (!FS.existsSync(PATH_FILE)) {
                FS.mkdirSync(PATH_FILE);
            }
            let fullPath = PATH_FILE + "/" + nameFile;
            if (!FS.existsSync(fullPath)) {
                let file = FS.createWriteStream(fullPath);
                data.fileInput.pipe(file);
                await loadFileDB(this.db, { name_file: nameFile, data_file: '' });
                req.yar.set('message', { key: 'El archivo se registró de forma satisfactoria' });
            } else {
                req.yar.set('message', { key: 'El archivo ya se encuentra registrado' });
            }
            break;
        case 'XML':
            try {
                let buffer = data.fileInput.read();
                let json = XML_TO_JSON.toJson(buffer);
                let parameters = { name_file: nameFile, data_file: json };
                await loadFileDB(this.db, parameters);
                req.yar.set('message', { key: 'Archivo convertido de forma satisfactoria' });
            } catch (err) {
                console.log(err);
                req.yar.set('message', { key: 'Ocurrió un error al hacer la conversión del archivo' + err });
            }
            break;
        case 'JSON':
            let buffer = data.fileInput.read();
            let dataClean = JSON.parse(buffer.toString('utf8'));
            let listRol = dataClean.list_rol;
            let text = ''; let cont = 1;
            let listData = [];
            for (let i = 0; i < listRol.length; i++) {
                if (text == '') {
                    text = text + "( $" + cont + ", $" + (++cont) + " )";
                } else {
                    text = text + ",( $" + cont + ", $" + (++cont) + " )";
                }
                cont++;
                listData.push(listRol[i].rol.name);
                listData.push(listRol[i].rol.description);
            }
            let query = {
                name: 'fetch-roles',
                text: 'INSERT INTO roles(name, description ) VALUES ' + text,
                values: listData
            }
            await saveRol(req, query);
            req.yar.set('message', { key: 'Archivo leído correctamente. La información fue cargada a la base de datos' });
            break;
        case 'XLS':
            let bufferData = data.fileInput.read();
            let dataString = XLSX.parse(bufferData);
            let row = dataString[0].data;
            let dataTxt = [];
            writingData(dataTxt, row[2], '01');
            for (let i = 4; i < row.length; i++) {
                writingData(dataTxt, row[i], '03');
            }
            var fileTxt = FS.createWriteStream(PATH_FILE + '/' + nameFileTxt);
            fileTxt.on('error', function (err) {
                req.yar.set('message', { key: 'Error descargando el archivo. ' + err });
            });
            for (let j = 0; j < dataTxt.length; j++) {
                fileTxt.write(dataTxt[j] + '\n');
            }
            fileTxt.end();
            await new Promise(resolve => {
                fileTxt.on('finish', () => {
                    resolve();
                });
            });
            download = true;
            break;
        default:
            req.yar.set('message', { key: 'El archivo no coincide con las extensiones permitidas' });
            break;
    }
    if (download) {
        return res.file("file" + '/' + nameFileTxt, {
            mode: 'attachment',
            filename: nameFileTxt
        });
    } else {
        return res.redirect('/uploadFile');
    }
}

exports.downloadJSON = function (req, res) {
    let credentials = req.auth.credentials.dToken;
    let message = req.yar.get('message');
    if (message) {
        req.yar.clear('message');
        return res.view('loadFile/downloadJSON', { message: message.key, credentials: credentials });
    }
    return res.view('loadFile/downloadJSON', { credentials: credentials });
}

exports.searchFile = async function (req, res) {
    let query = {
        name: 'fetch-files',
        text: "SELECT id_file, name_file FROM files Where to_char(id_file, '999') like $1",
        values: ["%" + req.query.id + "%"]
    }
    try {
        let files = await this.db.query(query);
        return { files: files.rows };
    } catch (err) {
        console.log(err);
        return { files: [] };
    }
}

exports.downloadJSONFile = async function (req, res) {
    let data = req.payload;
    let nameFile = data.idFile + "_" + (((data.name_file).split("."))[0]) + ".JSON";

    let query = {
        text: "SELECT data_file FROM files where id_file = $1",
        values: [data.idFile]
    }

    let files = await this.db.query(query);

    let dataFileJSON = files.rows[0].data_file;
    let jsonData = JSON.stringify(dataFileJSON);
    var fileJSON = FS.createWriteStream(PATH_FILE + '/' + nameFile);
    fileJSON.on('error', function (err) {
        req.yar.set('message', { key: 'Error descargando el archivo. ' + err });
        console.log(err);
        return res.redirect("/");
    });
    fileJSON.write(jsonData);
    fileJSON.end();
    return res.file("file" + '/' + nameFile, {
        mode: 'attachment',
        filename: nameFile
    });
}

exports.viewXLS = function (req, res) {
    let credentials = req.auth.credentials.dToken;
    let message = req.yar.get('message');
    if (message) {
        req.yar.clear('message');
        return res.view('loadFile/generateXLS', { message: message.key, credentials: credentials });
    }
    return res.view('loadFile/generateXLS', { credentials: credentials });
}

exports.generateXLS = async function (req, res) {
    let query = {
        text: "SELECT id_file, name_file, data_file FROM files",
        values: []
    }

    let files = await this.db.query(query);
    let workbook = EXCEL_BUILD.createWorkbook(PATH_FILE, 'reporteFile.xlsx');
    var sheet1 = workbook.createSheet('File data', 20, 20);
    sheet1.merge({ col: 1, row: 1 }, { col: 5, row: 1 });
    sheet1.set(1, 1, 'LISTA DE ARCHIVOS CARGADOS A LA FECHA');
    sheet1.set(1, 3, 'id_file');
    sheet1.set(2, 3, 'name_file');
    sheet1.set(3, 3, 'data_file');
    let dataFile = files.rows;
    let row = 4;
    for (let i = 0; i < dataFile.length; i++) {
        sheet1.set(1, row, dataFile[i].id_file);
        sheet1.set(2, row, dataFile[i].name_file);
        sheet1.set(3, row, JSON.stringify(dataFile[i].data_file));
        row++;
    }
    await workbook.save(function (value, err) {
        if (err) {
            workbook.cancel();
        }
    });
    return res.file('file/reporteFile.xlsx', {
        mode: 'attachment',
        filename: 'reporteFile.xlsx'
    });
}

async function loadFileDB(db, parameters) {
    try {
        let query = '';
        if (parameters.data_file == "") {
            query = {
                name: 'fetch-files',
                text: 'INSERT INTO files(name_file ) VALUES( $1 )',
                values: [parameters.name_file]
            }
        } else {
            query = {
                name: 'fetch-files',
                text: 'INSERT INTO files(name_file, data_file ) VALUES( $1, $2 )',
                values: [parameters.name_file, parameters.data_file]
            }
        }
        await db.query(query);
    } catch (err) {
        console.log(err);
        req.yar.set('message', { key: 'Ocurrió un error registrar los archivos en la base de datos' + err });
    }
}

async function saveRol(req, query) {
    try {
        await req.server.methods.db.query(query);
    } catch (err) {
        console.log(err);
        req.yar.set('message', { key: 'Ocurrió un error al cargar los roles a la base de datos' + err });
    }
}

function writingData(dataFileTxt, rowData, tipo) {
    let content = tipo;
    for (let i = 0; i < rowData.length; i++) {
        content = content + rowData[i];
    }
    dataFileTxt.push(content);
}