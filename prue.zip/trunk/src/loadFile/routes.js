'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [
{
    method: 'GET',
    path: '/loadFile',
    handler: HANDLERS.loadInputView
},
{
    method: 'GET',
    path: '/uploadFile',
    handler: HANDLERS.uploadFIleView
},
{
    method: 'POST',
    path: '/processFile',
    config: {
        payload: {
            maxBytes: 209715200,
            output: 'stream',
            parse: true
        }
    },
    handler: HANDLERS.processFile
},
{
    method: 'GET',
    path: '/download/JSON',
    handler: HANDLERS.downloadJSON
},
{
    method: 'GET',
    path: '/searchFile',
    handler: HANDLERS.searchFile
},
{
    method: 'POST',
    path: '/downloadJSON',
    handler: HANDLERS.downloadJSONFile
},
{
    method: 'GET',
    path: '/fileXLS',
    handler: HANDLERS.viewXLS
},
{
    method: 'GET',
    path: '/downloadXLS',
    handler: HANDLERS.generateXLS
}
]