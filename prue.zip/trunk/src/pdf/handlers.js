'use strict';

const path = require('path');
const FS = require('fs');
const ZIP = require('zip-folder');


const HummusRecipe = require('hummus-recipe');
//const outputDir = path.join(__dirname, 'output');

exports.splitPDF = function (req, res) {
    let pdfDoc = new HummusRecipe(__dirname + "/" + 'input.pdf');
    pdfDoc.split(outputDir, 'prefix').endPDF();
    return "hola";
}

exports.uploadPDF = function (req, res) {
    return res.view('pdf/uploadPdf');
}

exports.savePDF = function (req, res) {
    let obj = req.payload;
    let public_tmp_path = this.SERVER_PATH + "/public/tmp";
    if (FS.existsSync(public_tmp_path)) {
        rmDir(public_tmp_path);
    }
    FS.mkdirSync(public_tmp_path);
    FS.mkdirSync(public_tmp_path + "/output");
    FS.writeFileSync(public_tmp_path + "/" + obj.nameFile, obj.pdfFile);
    let pdfDoc = new HummusRecipe(public_tmp_path + "/" + obj.nameFile);
    let outputDir = path.join(public_tmp_path, '/output');
    pdfDoc.split(outputDir, obj.nameFile.slice(0, -4)).endPDF();
    return new Promise(resolve => {
        ZIP(outputDir, public_tmp_path + "/output.zip", err => {
            if (err) {
                console.log(err);
                resolve(res.file(404));
            } else {
                resolve(res.file("tmp/output.zip"));
            }
        });
    })
}

var rmDir = function (dirPath) {
    try { var files = FS.readdirSync(dirPath); }
    catch (e) { return; }
    if (files.length > 0)
        for (var i = 0; i < files.length; i++) {
            var filePath = dirPath + '/' + files[i];
            if (FS.statSync(filePath).isFile())
                FS.unlinkSync(filePath);
            else
                rmDir(filePath);
        }
    FS.rmdirSync(dirPath);
};
