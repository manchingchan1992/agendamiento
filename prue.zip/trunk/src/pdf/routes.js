'use strict';

'use strict';

const HANDLERS = require('./handlers.js');

module.exports = [/*{
    method: 'GET',
    path: '/',
    config: { auth: false },
    handler: HANDLERS.splitPDF
},*/ {
    method: 'GET',
    path: '/uploadPDF',
    config: { auth: false },
    handler: HANDLERS.uploadPDF
}, {
    method: 'POST',
    path: '/savePDF',
    config: {
        auth: false,
        payload: {
            //parse: false,
            maxBytes: 50000000
        }
    },
    handler: HANDLERS.savePDF
}]