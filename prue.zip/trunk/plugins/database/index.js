'use strict';

const { Pool, Client } = require("pg");
//const CONN_STRING = 'postgresql://postgres:postgres@10.10.10.151:5432/node';
var db;

const DATABASE = {
    name: 'database',
    register: function (server, options) {
        db = new Pool({
            connectionString: options.connectionString,
        })

        server.method({
            name: 'db.query',
            method: async (query) => {
                return await db.query(query);
            }
        });

        server.method({
            name: 'db.getUsers',
            method: async () => {
                let query = {
                    text: 'select id, name, username, password, rol, email from public.users',
                }
                return await db.query(query);
            }
        });
    }
}

//DATABASE.register.attributes = require('./package.json');
DATABASE.register.attributes = {  
    name: 'database',
    version: '1.0.0'
  }

module.exports = DATABASE