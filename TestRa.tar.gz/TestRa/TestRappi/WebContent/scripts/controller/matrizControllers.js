function matrizController($scope,$routeParams,calcularMatriz) {

	$scope.calcularMatriz = function(){
					
		var data = 8;
			calcularMatriz(data).then(function(data){
				
				$scope.result = data;
				$.unblockUI();
																									
			});
					
	};
	
}