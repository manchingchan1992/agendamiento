package com.test.backend.utils;

public enum TipoOperacion {

	QUERY("QUERY"),
	UPDATE("QUERY");
	
	private String value;

	TipoOperacion(String value) {
		this.value = value;
	}
}
