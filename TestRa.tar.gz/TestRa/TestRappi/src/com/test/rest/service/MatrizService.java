package com.test.rest.service;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;

import org.apache.taglibs.standard.lang.jstl.IntegerDivideOperator;

import com.test.backend.converter.InfoConverter;
import com.test.backend.utils.OperacionesUtils;
import com.test.backend.utils.TipoOperacion;
import com.test.rest.pojo.InfoMatriz;
import com.test.rest.pojo.InputMatriz;

@Path("/matrizService")
public class MatrizService {
	
	/*@GET
	@Produces("application/json")
	@Path("/calcularMatriz/{data}")
	public List<Integer> calcularMatriz(
			@PathParam("data") InfoMatriz data, @Context HttpServletRequest request) {
		List<Integer> lstResult = Arrays.asList(4,4,4);
		return lstResult;
	}*/
	
	@GET
	@Produces("application/json")
	@Path("/calcularMatriz/{data}")
	public List<Integer> calcularMatriz(
			@PathParam("data") String data, @Context HttpServletRequest request) {
		List<Integer> lstResult = Arrays.asList(4,4,4);
		InfoConverter infoConverter = new InfoConverter();
		try {
			InputMatriz inputMatriz = infoConverter.convertirEntradaInfo(data);
			inputMatriz.getLstInfo().forEach(p->{
			  p.getDimension();
			  p.getNumeroOperaciones();
			  p.getLstOperaciones().forEach(c->{
				  if(c.getTipoOperacion().equals(TipoOperacion.UPDATE.name())){
					  inputMatriz.getMiMatriz()[c.getX1()][c.getY1()][c.getZ1()] = c.getValor(); 
				  }else{
					 int resultado= OperacionesUtils.sum(c.getX1(), c.getY1(), c.getZ1(), c.getX2(), c.getY2(), c.getZ2(), inputMatriz.getMiMatriz());
					 lstResult.add(resultado);
				  }
			  });
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lstResult;
	}
}
