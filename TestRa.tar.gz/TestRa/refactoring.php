<?php
public function post_confirm(){
	$id= Input::get('service_id');
	$servicio= Service::find('$id');
	$result= array();
	try{	  
	  if($servicio!=null){
	    if($servicio->status_id=='6'){
		$result = Response::json(array('error'=>'2'));
	    }else if($servicio->status_id=='1' && $servicio->driver_id==null){
		//se actualiza la informacion
		actualizarBD(Input::get('driver_id'),$id);

		$pushMessage = 'Tu servicio ha sido confirmado!';
		$servicio = Service::find($id);
		$push = Push.make();
		if($servicio->user->uuid==''){
		   $result = Response::json(array('error'=>'0'));
		}else{		   
		   //Se notifica al usuario
		   $result = $push->android2($servicio->user->uuid,$pushMessage,1,'default','Open',array('serviceId'=>$servicio->id));
		   if($servicio->user->type=='1'){//Iphone
		      $result = $push->ios($servicio->user->uuid,$pushMessage,1,'honk.wav','Open',array('serviceId'=>$servicio->id));
		   }
		}
            }else{
		$result = Response::json(array('error'=>'1'));
	    }
	  }
	}catch(Exception $e){
	    $result = Response::json(array('error'=>'3'));
	}
	return $result;
}

public function actualizarBD($driver_id,$id){
     try{
	//Se actualiza el servicio con el conductor y estado 2
	$servicio = Service::update($id, array(
		    'driver_id'=> $driver_id,
		    'status_id'=> '2'));
	//Se actualiza la disponibilidad del conductor
	Driver::update($driver_id, array('available'=>'0'));

	$driverTmp = Driver::find($driver_id);
	Service::update($id, array(
		'car_id'=> $driverTmp->car_id));	
	
     }catch(Exception $e){
	throw new Exception('Ocurrio un error confirmando el servicio ');
     }
}

?>
