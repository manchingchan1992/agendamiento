package main;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import dto.Director;
import dto.Empleado;
import dto.Llamada;
import dto.Operario;
import dto.Supervisor;
import negocio.Dispatcher;

public class Principal {
	
	private static final int numEmpleados = 2;

	public static void main(String[] args) {
		//Dispatcher dispatcher = new Dispatcher();
		
		
		/*dispatcher.getOperarios().add(new Operario("Daniel"));
		dispatcher.getOperarios().add(new Operario("Esteban"));
		dispatcher.getSupervisores().add(new Supervisor("Alejandro"));
		dispatcher.getDirectores().add(new Director("Catalina"));*/
		
		
		ArrayList<Llamada> llamadas = new ArrayList<>();
		llamadas.add(new Llamada("1", "Llamando", 20));
		llamadas.add(new Llamada("2", "Llamando", 4));
		llamadas.add(new Llamada("3", "Llamando", 1));
		llamadas.add(new Llamada("4", "Llamando", 20));
		llamadas.add(new Llamada("5", "Llamando", 3));
		
		
		
		ExecutorService executor = Executors.newFixedThreadPool(10);
		for(Llamada llamada: llamadas) {
			Runnable disp = new Dispatcher(llamada);
			executor.execute(disp);
		}
		executor.shutdown();
//		while (!executor.isTerminated()) {
//			
//		}
	}

}
