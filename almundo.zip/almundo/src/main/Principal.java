package main;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import dto.Director;
import dto.Empleado;
import dto.Llamada;
import dto.Operario;
import dto.Supervisor;
import negocio.Dispatcher;

public class Principal {
	
	private static final int numEmpleados = 2;

	public static void main(String[] args) {
		//Dispatcher dispatcher = new Dispatcher();
		
		
		Dispatcher.operarios.add(new Operario("Diego"));
		//Dispatcher.operarios.add(new Operario("Cata"));
		//Dispatcher.operarios.add(new Operario("Camilo"));
		
		
		ArrayList<Llamada> llamadas = new ArrayList<>();
		llamadas.add(new Llamada("1", "Llamando", 10));
		llamadas.add(new Llamada("2", "Llamando", 15));
		llamadas.add(new Llamada("3", "Llamando", 3));
		llamadas.add(new Llamada("4", "Llamando", 3));
		llamadas.add(new Llamada("5", "Llamando", 3));
		llamadas.add(new Llamada("6", "Llamando", 20));
//		llamadas.add(new Llamada("7", "Llamando", 4));
//		llamadas.add(new Llamada("8", "Llamando", 6));
//		llamadas.add(new Llamada("9", "Llamando", 15));
//		llamadas.add(new Llamada("10", "Llamando", 3));
//		llamadas.add(new Llamada("11", "Llamando", 6));
//		llamadas.add(new Llamada("12", "Llamando", 15));
//		llamadas.add(new Llamada("13", "Llamando", 3));
		
		
//		Dispatcher d = new Dispatcher(llamadas.get(0));
//		Dispatcher d1 = new Dispatcher(llamadas.get(1));
//		Dispatcher d2 = new Dispatcher(llamadas.get(2));
		ExecutorService executor = Executors.newFixedThreadPool(10);
		for(Llamada llamada: llamadas) {
			Runnable disp = new Dispatcher(llamada);
			executor.execute(disp);
		}
		executor.shutdown();
//		while (!executor.isTerminated()) {
//			
//		}
	}

}
