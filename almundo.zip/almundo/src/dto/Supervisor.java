package dto;

public class Supervisor extends Empleado{

	
	public Supervisor(String nombre) {
		super(nombre);
	}
	
	@Override
	public void atenderLlamada() {
		System.out.println("Atendiendo llamada desde supervisor ");
	}

	@Override
	synchronized public void cambiarEstado() {
		if(super.isEstado()) {
			super.setEstado(false);
		}else{
			super.setEstado(true);
		}
		
	}

}
