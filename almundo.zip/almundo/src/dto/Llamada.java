package dto;

public class Llamada {
	private String origen;
	private String estado;
	private int tiempo;
	private Empleado empleado;
	
	
	public Llamada(String origen, String estado, int tiempo) {
		this.origen = origen;
		this.estado = estado;
		this.tiempo = tiempo;
		
	}


	public String getOrigen() {
		return origen;
	}


	public void setOrigen(String origen) {
		this.origen = origen;
	}


	public String getEstado() {
		return estado;
	}


	public void setEstado(String estado) {
		this.estado = estado;
	}


	public int getTiempo() {
		return tiempo;
	}


	public void setTiempo(int tiempo) {
		this.tiempo = tiempo;
	}


	public Empleado getEmpleado() {
		return empleado;
	}


	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	
	
	
	
}
