package dto;

public class Operario extends Empleado{

	public Operario(String nombre) {
		super(nombre);
	}
	
	@Override
	public void atenderLlamada() {
		System.out.println("Atendiendo llamada desde operador ");
	}

	@Override
	public void cambiarEstado() {
		if(super.isEstado()) {
			super.setEstado(false);
		}else{
			super.setEstado(true);
		}
		
	}

}
