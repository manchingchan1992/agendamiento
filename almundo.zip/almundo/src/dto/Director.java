package dto;

public class Director extends Empleado{

	
	public Director(String nombre) {
		super(nombre);
	}
	
	@Override
	public void atenderLlamada() {
		System.out.println("Atendiendo llamada como director, nombre "+super.getNombre());
		
	}

	@Override
	public void cambiarEstado() {
		if(super.isEstado()) {
			super.setEstado(false);
		}else {
			super.setEstado(true);	
		}		
	}
	
	
	

}
