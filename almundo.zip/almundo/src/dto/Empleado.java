package dto;

public abstract class Empleado {

	private String nombre;
	private boolean estado = false;
	
	public abstract void atenderLlamada();
	public abstract void cambiarEstado();
	
	public Empleado(String nombre) {
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public boolean isEstado() {
		return estado;
	}
	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	
	

}
