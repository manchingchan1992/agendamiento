package negocio;

import java.util.ArrayList;
import java.util.List;

import dto.Director;
import dto.Empleado;
import dto.Llamada;
import dto.Operario;
import dto.Supervisor;


public class Dispatcher implements Runnable{
	private List<Empleado> operarios = new ArrayList<>();
	private List<Empleado> supervisores = new ArrayList<>();
	private List<Empleado> directores = new ArrayList<>();
	
	private Llamada llamada;

	public Dispatcher(Llamada llamada){
		this.llamada = llamada;
	}
	
	@Override
	public void run() {
		System.out.println( Thread.currentThread().getName()+ " COMIENZA A PROCESAR LA LLAMADA "+ this.llamada.getOrigen() );
		esperarXsegundos(this.llamada.getTiempo());
		System.out.println( Thread.currentThread().getName()+ " SE TERMINA DE PROCESAR LA LLAMADA "+ this.llamada.getOrigen() );
	}
	
	private void esperarXsegundos(int segundos) {
		try {
			Thread.sleep(segundos * 1000);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
		}
	
	public void dispatchCall(Llamada llamada) {
		///////////////////
		Empleado empleado = null;
		if ((empleado = encontrarEmpleadoLibre(operarios)) != null) {
			llamada.setEmpleado(empleado);
		} else if ((empleado = encontrarEmpleadoLibre(supervisores)) != null) {
			Supervisor supervisor = (Supervisor) empleado;
		} else if ((empleado = encontrarEmpleadoLibre(directores)) != null) {
			llamada.setEmpleado(empleado);
		}
	
	}

	public Empleado encontrarEmpleadoLibre(List<Empleado> empleados) {
		Empleado empleadoLibre = null;
		cicloValidacion: for (Empleado e : empleados) {
			if (e instanceof Operario) {
				if (!((Operario) e).isEstado()) {
					empleadoLibre = e;
					break cicloValidacion;
				}
			} else if (e instanceof Supervisor) {
				if (!((Supervisor) e).isEstado()) {
					empleadoLibre = e;
					break cicloValidacion;
				}
			} else {
				if (!((Director) e).isEstado()) {
					empleadoLibre = e;
					break cicloValidacion;
				}
			}
		}
		return empleadoLibre;
	}
	

	public List<Empleado> getOperarios() {
		return operarios;
	}

	public void setOperarios(List<Empleado> operarios) {
		this.operarios = operarios;
	}

	public List<Empleado> getSupervisores() {
		return supervisores;
	}

	public void setSupervisores(List<Empleado> supervisores) {
		this.supervisores = supervisores;
	}

	public List<Empleado> getDirectores() {
		return directores;
	}

	public void setDirectores(List<Empleado> directores) {
		this.directores = directores;
	}

	
	
}
