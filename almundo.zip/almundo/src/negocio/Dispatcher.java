package negocio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import dto.Director;
import dto.Empleado;
import dto.Llamada;
import dto.Operario;
import dto.Supervisor;

public class Dispatcher implements Runnable {

	public static List<Empleado> operarios = new ArrayList<>();
	public static List<Empleado> supervisores =new ArrayList<>();
	public static List<Empleado> directores = new ArrayList<>();

	private Llamada llamada;

	public Dispatcher(Llamada llamada) {
		this.llamada = llamada;
	}

	@Override
	public void run() {

		dispatchCall(this.llamada);
		System.out.println(Thread.currentThread().getName() + " ------ " + this.llamada.getEmpleado().getNombre()
				+ " COMIENZA A PROCESAR LA LLAMADA " + this.llamada.getOrigen());
		tiempoAtencion(this.llamada.getTiempo());
		//llamada.getEmpleado().setEstado(false);
		System.out.println(Thread.currentThread().getName() + " ------ " + this.llamada.getEmpleado().getNombre()
				+ " SE TERMINA DE PROCESAR LA LLAMADA " + this.llamada.getOrigen());
	}

	 private void dispatchCall(Llamada llamada) {
		///////////////////
		Empleado empleado = null;
		boolean banderaBusqueda = true;
		//llamada en espera
		while (banderaBusqueda) {
			if ((empleado = encontrarEmpleadoLibre(operarios)) != null) {
				Operario operario = (Operario) empleado;
				llamada.setEmpleado(operario);
				operario.cambiarEstado();
				banderaBusqueda = false;
			} else if ((empleado = encontrarEmpleadoLibre(supervisores)) != null) {
				Supervisor supervisor = (Supervisor) empleado;
				llamada.setEmpleado(supervisor);
				supervisor.cambiarEstado();
				banderaBusqueda = false;
			} else if ((empleado = encontrarEmpleadoLibre(directores)) != null) {
				Director director = (Director) empleado;
				llamada.setEmpleado(director);
				director.cambiarEstado();
				banderaBusqueda = false;
			}
			//System.out.println("llamada en espera " + llamada.getOrigen());
		}

	}

	private void tiempoAtencion(int segundos) {
		try {
			Thread.sleep(segundos * 1000);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
	}

	private Empleado encontrarEmpleadoLibre(List<Empleado> empleados) {
		Empleado empleadoLibre = null;
		cicloValidacion: for (Empleado e : empleados) {
			if (e instanceof Operario) {
				if (!((Operario) e).isEstado()) {
					empleadoLibre = e;
					break cicloValidacion;
				}
			} else if (e instanceof Supervisor) {
				if (!((Supervisor) e).isEstado()) {
					empleadoLibre = e;
					break cicloValidacion;
				}
			} else {
				if (!((Director) e).isEstado()) {
					empleadoLibre = e;
					break cicloValidacion;
				}
			}
		}
		return empleadoLibre;
	}

	public List<Empleado> getOperarios() {
		return operarios;
	}

	public void setOperarios(List<Empleado> operarios) {
		this.operarios = operarios;
	}

	public List<Empleado> getSupervisores() {
		return supervisores;
	}

	public void setSupervisores(List<Empleado> supervisores) {
		this.supervisores = supervisores;
	}

	public List<Empleado> getDirectores() {
		return directores;
	}

	public void setDirectores(List<Empleado> directores) {
		this.directores = directores;
	}

}
